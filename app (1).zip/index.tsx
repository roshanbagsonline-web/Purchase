import React, { useState, useEffect, useMemo, useRef } from 'react';
import { createRoot } from 'react-dom/client';

// To inform TypeScript about the global XLSX object from the script tag in index.html
declare var XLSX: any;

// --- Type Definitions ---
interface Department {
    id: string;
    name: string;
    gst: 5 | 18;
    hsn: string;
}

interface Category {
    id: string;
    name: string;
    departments: Department[];
}

interface PurchaseEntry {
    id:string;
    departmentId: string;
    productName: string;
    hsn: string;
    brandName: string;
    productCode: string;
    color: string;
    size: string;
    warranty: string;
    demBarcode: string;
    pattern: string;
    style: string;
    quantity: number;
    landingRate: number;
    mrp: number;
    sellingPrice: number;
    marginPercentage: number;
    discountPercentage: number;
}

interface ProductAttributes {
    productNames: string[];
    brandNames: string[];
    productCodes: string[];
    colors: string[];
    sizes: string[];
    warranties: string[];
    patterns: string[];
    styles: string[];
}


// --- Main App Component ---
const App = () => {
    // --- State Management ---
    const [activePage, setActivePage] = useState('entry');
    const [categories, setCategories] = useState<Category[]>([]);
    const [purchaseEntries, setPurchaseEntries] = useState<PurchaseEntry[]>([]);
    const [productAttributes, setProductAttributes] = useState<ProductAttributes>({
        productNames: [], brandNames: [], productCodes: [], colors: [], sizes: [], warranties: [], patterns: [], styles: []
    });
    const [editingEntryId, setEditingEntryId] = useState<string | null>(null);
    const [viewingEntry, setViewingEntry] = useState<PurchaseEntry | null>(null);
    const [selectedEntryIds, setSelectedEntryIds] = useState<Set<string>>(new Set());

    // --- Memoized Derived State ---
    const departments = useMemo(() => categories.flatMap(c => c.departments), [categories]);

    // --- LocalStorage Persistence ---
    useEffect(() => {
        try {
            const storedDataRaw = localStorage.getItem('bag-store-data-v4');
            if (storedDataRaw) {
                const storedData = JSON.parse(storedDataRaw);
                setCategories(storedData.categories || []);
                setPurchaseEntries(storedData.purchaseEntries || []);
                setProductAttributes(storedData.productAttributes || {
                    productNames: [], brandNames: [], productCodes: [], colors: [], sizes: [], warranties: [], patterns: [], styles: []
                });
            } else {
                 // Attempt to load from old version and migrate
                const oldStoredDataRaw = localStorage.getItem('bag-store-data-v3');
                if (oldStoredDataRaw) {
                    const oldStoredData = JSON.parse(oldStoredDataRaw);
                    setCategories(oldStoredData.categories || []);
                    const entries = oldStoredData.purchaseEntries || [];
                    setPurchaseEntries(entries);
                    if (entries.length > 0) {
                        setProductAttributes(generateProductAttributes(entries));
                    }
                } else {
                    // Initialize with default data if nothing is stored
                    const defaultCategories: Category[] = Object.entries({
                        'Accessories': ['Belt', 'Card Holder', 'Clutches', 'Flask', 'Luggage Cover', 'Lunch Box Steel', 'Mens Wallet', 'Pencil Case', 'Raincoats', 'Travel Accessories', 'Umbrella', 'Vanity Case', 'Water Bottle Plastic', 'Water Bottle Steel', 'Winter Jackets', 'Womens Wallet', 'Water Bottle Glass', 'Lunch Box', 'Pvc Raincoats'],
                        'Bags': ['Backpack', 'Backpack With Trolley', 'College Bags', 'Executive Bags', 'Laptop Backpack', 'Laptop Sleeve', 'Leather Bags', 'Lunch Bags', 'Mother Bag', 'Rucksack', 'School Bags', 'Unisex Crossbody Bag'],
                        'Handbags': ['Handbags', 'Leather Handbags', 'Tote Bag', 'Women Backpack', 'Women Sling Bags'],
                        'Luggages': ['Briefcase', 'Duffle Bag', 'Duffle Trolley', 'Hard Luggage', 'Kids Luggage', 'Laptop Overnighter', 'Soft Luggage']
                    }).map(([categoryName, departmentNames]) => ({
                        id: crypto.randomUUID(),
                        name: categoryName,
                        departments: departmentNames.sort().map(deptName => ({
                            id: crypto.randomUUID(),
                            name: deptName,
                            gst: 18,
                            hsn: '4202'
                        }))
                    }));
                    setCategories(defaultCategories);
                }
            }
        } catch (error) {
            console.error("Failed to initialize state from localStorage", error);
        }
    }, []);

    const generateProductAttributes = (entries: PurchaseEntry[]): ProductAttributes => {
        const attributes: { [key in keyof ProductAttributes]: Set<string> } = {
            productNames: new Set(), brandNames: new Set(), productCodes: new Set(), colors: new Set(),
            sizes: new Set(), warranties: new Set(), patterns: new Set(), styles: new Set(),
        };

        entries.forEach(entry => {
            if (entry.productName?.trim()) attributes.productNames.add(entry.productName.trim());
            if (entry.brandName?.trim()) attributes.brandNames.add(entry.brandName.trim());
            if (entry.productCode?.trim()) attributes.productCodes.add(entry.productCode.trim());
            if (entry.color?.trim()) attributes.colors.add(entry.color.trim());
            if (entry.size?.trim()) attributes.sizes.add(entry.size.trim());
            if (entry.warranty?.trim()) attributes.warranties.add(entry.warranty.trim());
            if (entry.pattern?.trim()) attributes.patterns.add(entry.pattern.trim());
            if (entry.style?.trim()) attributes.styles.add(entry.style.trim());
        });

        return {
            productNames: Array.from(attributes.productNames).sort(),
            brandNames: Array.from(attributes.brandNames).sort(),
            productCodes: Array.from(attributes.productCodes).sort(),
            colors: Array.from(attributes.colors).sort(),
            sizes: Array.from(attributes.sizes).sort(),
            warranties: Array.from(attributes.warranties).sort(),
            patterns: Array.from(attributes.patterns).sort(),
            styles: Array.from(attributes.styles).sort(),
        };
    };

    useEffect(() => {
        const dataToStore = {
            categories,
            purchaseEntries,
            productAttributes
        };
        localStorage.setItem('bag-store-data-v4', JSON.stringify(dataToStore));
    }, [categories, purchaseEntries, productAttributes]);

    const updateProductAttributesFromEntry = (entry: Partial<PurchaseEntry>) => {
       setProductAttributes(prev => {
            const newAttributes = { ...prev };
            let changed = false;

            const checkAndAdd = (key: keyof ProductAttributes, value: string | undefined) => {
                const trimmedValue = value?.trim();
                if (trimmedValue) {
                    const lowerCaseList = newAttributes[key].map(item => item.toLowerCase());
                    if (!lowerCaseList.includes(trimmedValue.toLowerCase())) {
                        newAttributes[key] = [...newAttributes[key], trimmedValue].sort((a,b) => a.localeCompare(b));
                        changed = true;
                    }
                }
            };
            
            checkAndAdd('productNames', entry.productName);
            checkAndAdd('brandNames', entry.brandName);
            checkAndAdd('productCodes', entry.productCode);
            checkAndAdd('colors', entry.color);
            checkAndAdd('sizes', entry.size);
            checkAndAdd('warranties', entry.warranty);
            checkAndAdd('patterns', entry.pattern);
            checkAndAdd('styles', entry.style);
            
            return changed ? newAttributes : prev;
        });
    };

    // --- Category & Department Handlers ---
    const addCategory = (name: string) => {
        if (!name.trim()) return;
        if (categories.some(c => c.name.toLowerCase() === name.trim().toLowerCase())) {
            alert('A category with this name already exists.');
            return;
        }
        const newCategory: Category = { id: crypto.randomUUID(), name: name.trim(), departments: [] };
        setCategories(prev => [...prev, newCategory]);
    };

    const deleteCategory = (id: string) => {
        if (window.confirm('Are you sure you want to delete this category and all its departments? This cannot be undone.')) {
            setCategories(prev => prev.filter(c => c.id !== id));
        }
    };
    
    const addDepartment = (categoryId: string, name: string) => {
        if (!name.trim()) return;
        setCategories(prev => prev.map(c => {
            if (c.id === categoryId) {
                 if (c.departments.some(d => d.name.toLowerCase() === name.trim().toLowerCase())) {
                    alert('A department with this name already exists in this category.');
                    return c;
                }
                const newDepartment: Department = { id: crypto.randomUUID(), name: name.trim(), gst: 18, hsn: '4202' };
                return { ...c, departments: [...c.departments, newDepartment].sort((a, b) => a.name.localeCompare(b.name)) };
            }
            return c;
        }));
    };

    const deleteDepartment = (categoryId: string, departmentId: string) => {
        setCategories(prev => prev.map(c => 
            c.id === categoryId 
            ? { ...c, departments: c.departments.filter(d => d.id !== departmentId) } 
            : c
        ));
    };

    const updateDepartment = (categoryId: string, departmentId: string, updatedValues: Partial<Department>) => {
        setCategories(prev => prev.map(c => 
            c.id === categoryId 
            ? { ...c, departments: c.departments.map(d => d.id === departmentId ? { ...d, ...updatedValues } : d) } 
            : c
        ));
    };
    
    // --- Data Import Handler ---
    const handleImportData = (importedData: any) => {
        const isValid = importedData &&
                        Array.isArray(importedData.categories) &&
                        importedData.productAttributes &&
                        typeof importedData.productAttributes === 'object' &&
                        !Array.isArray(importedData.productAttributes);

        if (isValid) {
            const categoryCount = importedData.categories.length;
            const attributeCount = Object.keys(importedData.productAttributes).length;
            const nonEmptyAttributeCount = Object.values(importedData.productAttributes).filter((arr: any) => Array.isArray(arr) && arr.length > 0).length;

            const confirmationMessage = `Are you sure you want to import this data?\nThis will overwrite all of your existing categories and product attributes.\n\n--- IMPORT SUMMARY ---\nCategories: ${categoryCount}\nAttribute Lists: ${attributeCount} (${nonEmptyAttributeCount} with data)\n\nDo you want to proceed?`;

            if (window.confirm(confirmationMessage)) {
                setCategories(importedData.categories);
                setProductAttributes(importedData.productAttributes);
                alert('Data successfully imported!');
            }
        } else {
            alert("Error: Invalid data structure in JSON file. The file must contain a 'categories' array and a 'productAttributes' object.");
        }
    };

    // --- Purchase Entry Handlers ---
    const addPurchaseEntry = (entry: Omit<PurchaseEntry, 'id'>) => {
        const newEntry = { ...entry, id: crypto.randomUUID() };
        setPurchaseEntries(prev => [newEntry, ...prev]);
        updateProductAttributesFromEntry(entry);
    };
    
    const addMultiplePurchaseEntries = (entries: Omit<PurchaseEntry, 'id'>[]) => {
        const newEntries = entries.map(entry => ({...entry, id: crypto.randomUUID()}));
        setPurchaseEntries(prev => [...newEntries, ...prev]);
        
        // Batch update attributes
        const attributesToUpdate: { [key in keyof ProductAttributes]: Set<string> } = {
            productNames: new Set(), brandNames: new Set(), productCodes: new Set(), colors: new Set(),
            sizes: new Set(), warranties: new Set(), patterns: new Set(), styles: new Set(),
        };

        entries.forEach(entry => {
            if (entry.productName?.trim()) attributesToUpdate.productNames.add(entry.productName.trim());
            if (entry.brandName?.trim()) attributesToUpdate.brandNames.add(entry.brandName.trim());
            if (entry.productCode?.trim()) attributesToUpdate.productCodes.add(entry.productCode.trim());
            if (entry.color?.trim()) attributesToUpdate.colors.add(entry.color.trim());
            if (entry.size?.trim()) attributesToUpdate.sizes.add(entry.size.trim());
            if (entry.warranty?.trim()) attributesToUpdate.warranties.add(entry.warranty.trim());
            if (entry.pattern?.trim()) attributesToUpdate.patterns.add(entry.pattern.trim());
            if (entry.style?.trim()) attributesToUpdate.styles.add(entry.style.trim());
        });
        
        setProductAttributes(prev => {
            const newAttributes = { ...prev };
            let changed = false;
            for (const key in attributesToUpdate) {
                const attrKey = key as keyof ProductAttributes;
                const valuesToAdd = Array.from(attributesToUpdate[attrKey]);
                if (valuesToAdd.length > 0) {
                     const currentValuesLower = new Set(newAttributes[attrKey].map(v => v.toLowerCase()));
                     const newUniqueValues = valuesToAdd.filter(v => !currentValuesLower.has(v.toLowerCase()));
                     if (newUniqueValues.length > 0) {
                         newAttributes[attrKey] = [...newAttributes[attrKey], ...newUniqueValues].sort((a,b) => a.localeCompare(b));
                         changed = true;
                     }
                }
            }
            return changed ? newAttributes : prev;
        });
    };


    const updatePurchaseEntry = (id: string, updatedEntryData: Partial<Omit<PurchaseEntry, 'id'>>) => {
        setPurchaseEntries(prev => prev.map(e => e.id === id ? { ...e, ...updatedEntryData, id } : e));
        updateProductAttributesFromEntry(updatedEntryData);
        setEditingEntryId(null);
    };
    
    const deletePurchaseEntry = (id: string) => {
        if (window.confirm('Are you sure you want to delete this entry? This action cannot be undone.')) {
            setPurchaseEntries(prev => prev.filter(e => e.id !== id));
            setSelectedEntryIds(prev => {
                const newSet = new Set(prev);
                newSet.delete(id);
                return newSet;
            });
        }
    };

    const handleClearAllEntries = () => {
        if (window.confirm('Are you sure you want to delete ALL purchase entries? This action cannot be undone and will not affect your saved product attributes.')) {
            setPurchaseEntries([]);
            setSelectedEntryIds(new Set());
        }
    };

    const handleDeleteSelectedEntries = (idsToDelete: Set<string>) => {
        if (idsToDelete.size === 0) return;
        if (window.confirm(`Are you sure you want to delete ${idsToDelete.size} selected entries? This action cannot be undone.`)) {
            setPurchaseEntries(prev => prev.filter(e => !idsToDelete.has(e.id)));
            setSelectedEntryIds(new Set());
        }
    };
    
    const handleStartEdit = (id: string) => {
        setEditingEntryId(id);
        setViewingEntry(null);
    };

    return (
        <>
            <style>{STYLES}</style>
            <div className="app-layout">
                <aside className="sidebar">
                    <div className="sidebar-header">
                        <h1>Bag Store</h1>
                    </div>
                    <nav className="sidebar-nav">
                        <button onClick={() => setActivePage('entry')} className={activePage === 'entry' ? 'active' : ''} aria-current={activePage === 'entry'}>Purchase Entry</button>
                        <button onClick={() => setActivePage('excel-converter')} className={activePage === 'excel-converter' ? 'active' : ''} aria-current={activePage === 'excel-converter'}>Excel Converter</button>
                        <button onClick={() => setActivePage('attributes')} className={activePage === 'attributes' ? 'active' : ''} aria-current={activePage === 'attributes'}>Product Attributes</button>
                        <button onClick={() => setActivePage('settings')} className={activePage === 'settings' ? 'active' : ''} aria-current={activePage === 'settings'}>Settings</button>
                    </nav>
                </aside>
                <main className="main-content">
                    {activePage === 'entry' && 
                        <PurchaseEntryPage 
                            categories={categories}
                            departments={departments} 
                            entries={purchaseEntries}
                            productAttributes={productAttributes}
                            onAddEntry={addPurchaseEntry}
                            onUpdateEntry={updatePurchaseEntry}
                            onDeleteEntry={deletePurchaseEntry}
                            onClearAllEntries={handleClearAllEntries}
                            onDeleteSelectedEntries={handleDeleteSelectedEntries}
                            editingEntryId={editingEntryId}
                            onStartEdit={handleStartEdit}
                            onCancelEdit={() => setEditingEntryId(null)}
                            onViewEntry={setViewingEntry}
                            selectedEntryIds={selectedEntryIds}
                            setSelectedEntryIds={setSelectedEntryIds}
                        />
                    }
                     {activePage === 'excel-converter' &&
                        <ExcelConverterPage
                            categories={categories}
                            departments={departments}
                            onAddMultipleEntries={addMultiplePurchaseEntries}
                        />
                    }
                    {activePage === 'attributes' && 
                        <ProductAttributesPage 
                            attributes={productAttributes}
                            setAttributes={setProductAttributes}
                        />
                    }
                    {activePage === 'settings' && 
                        <SettingsPage 
                            categories={categories} 
                            productAttributes={productAttributes}
                            onAddCategory={addCategory}
                            onDeleteCategory={deleteCategory}
                            onAddDepartment={addDepartment}
                            onDeleteDepartment={deleteDepartment}
                            onUpdateDepartment={updateDepartment}
                            onImportData={handleImportData}
                        />
                    }
                </main>
                {viewingEntry && <ViewEntryModal entry={viewingEntry} departments={departments} onClose={() => setViewingEntry(null)} />}
            </div>
        </>
    );
};

// --- Settings Page Component ---
const SettingsPage = ({ categories, productAttributes, onAddCategory, onDeleteCategory, onAddDepartment, onDeleteDepartment, onUpdateDepartment, onImportData }: {
    categories: Category[];
    productAttributes: ProductAttributes;
    onAddCategory: (name: string) => void;
    onDeleteCategory: (id: string) => void;
    onAddDepartment: (categoryId: string, name: string) => void;
    onDeleteDepartment: (categoryId: string, departmentId: string) => void;
    onUpdateDepartment: (categoryId: string, departmentId: string, updatedValues: Partial<Department>) => void;
    onImportData: (data: any) => void;
}) => {
    const [newCategoryName, setNewCategoryName] = useState('');
    const [newDepartmentNames, setNewDepartmentNames] = useState<{ [key: string]: string }>({});
    const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
    const importFileRef = useRef<HTMLInputElement>(null);

    const handleAddCategory = (e: React.FormEvent) => {
        e.preventDefault();
        onAddCategory(newCategoryName);
        setNewCategoryName('');
    };

    const handleAddDepartment = (e: React.FormEvent, categoryId: string) => {
        e.preventDefault();
        const deptName = newDepartmentNames[categoryId] || '';
        onAddDepartment(categoryId, deptName);
        setNewDepartmentNames(prev => ({ ...prev, [categoryId]: '' }));
    };
    
    const toggleCategory = (categoryId: string) => {
        setExpandedCategories(prev => ({
            ...prev,
            [categoryId]: !prev[categoryId]
        }));
    };

    const handleExport = () => {
        const dataToExport = {
            categories,
            productAttributes
        };
        const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
            JSON.stringify(dataToExport, null, 2)
        )}`;
        const link = document.createElement("a");
        link.href = jsonString;
        link.download = "bag-store-backup.json";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleImportClick = () => {
        importFileRef.current?.click();
    };

    const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        const fileInput = event.target;

        if (!file) {
            if (fileInput) fileInput.value = '';
            return;
        }

        const reader = new FileReader();

        reader.onload = (e) => {
            const text = e.target?.result;

            if (typeof text !== 'string' || text.trim() === '') {
                alert("Import Failed: The selected file is empty or could not be read as text.");
                return;
            }

            let importedData;
            try {
                importedData = JSON.parse(text);
            } catch (error) {
                console.error("JSON Parsing Error:", error);
                alert("Import Failed: The file is not a valid JSON file. Please ensure it was exported from this application and has not been modified.");
                return;
            }
            
            // If we reach here, parsing was successful.
            onImportData(importedData);
        };

        reader.onerror = () => {
            console.error("FileReader Error:", reader.error);
            alert("Import Failed: An unexpected error occurred while trying to read the file.");
        };
        
        reader.onloadend = () => {
            // Always reset the file input to allow re-importing the same file
            if (fileInput) fileInput.value = '';
        };

        reader.readAsText(file);
    };

    return (
        <div className="page-container">
            <div className="page-header">
                <h2>Settings</h2>
                <p>Manage application settings, data, and structure.</p>
            </div>
            
            <div className="card">
                <h3>Data Management</h3>
                <p>Export all your category and product attribute data into a single JSON file for backup or sharing. You can then import this file on another device or browser to restore your setup.</p>
                <div className="form-actions" style={{marginTop: '1rem', justifyContent: 'flex-start'}}>
                    <button onClick={handleExport} className="primary-button">Export Data</button>
                    <button onClick={handleImportClick} className="secondary-button">Import Data</button>
                    <input
                        type="file"
                        ref={importFileRef}
                        onChange={handleFileImport}
                        accept=".json"
                        style={{ display: 'none' }}
                    />
                </div>
            </div>

            <div className="page-header" style={{marginTop: '2rem'}}>
                <h2>Manage Categories & Departments</h2>
                <p>Add or remove product categories, then manage the departments (sub-categories) within them.</p>
            </div>
            <div className="card">
                <form onSubmit={handleAddCategory} className="add-category-form">
                    <input 
                        type="text" 
                        value={newCategoryName}
                        onChange={e => setNewCategoryName(e.target.value)}
                        placeholder="New Category Name"
                    />
                    <button type="submit" className="primary-button">Add Category</button>
                </form>
            </div>

            {categories.length === 0 && <div className="card"><p>No categories found. Add one above to get started.</p></div>}
            
            <div className="category-list">
                {categories.map(category => (
                    <div key={category.id} className="card category-card">
                        <div className="category-header" onClick={() => toggleCategory(category.id)}>
                            <h3>
                                <span className={`toggle-icon ${expandedCategories[category.id] ? 'expanded' : ''}`}>▶</span>
                                {category.name}
                            </h3>
                            <button onClick={(e) => { e.stopPropagation(); onDeleteCategory(category.id); }} className="icon-button danger" aria-label={`Delete ${category.name} category`}>🗑️</button>
                        </div>
                        
                        {expandedCategories[category.id] && (
                            <div className="collapsible-content">
                                <form onSubmit={(e) => handleAddDepartment(e, category.id)} className="add-department-form">
                                    <input 
                                        type="text" 
                                        value={newDepartmentNames[category.id] || ''}
                                        onChange={e => setNewDepartmentNames(prev => ({ ...prev, [category.id]: e.target.value }))}
                                        placeholder="New Department Name"
                                    />
                                    <button type="submit" className="secondary-button">Add Department</button>
                                </form>

                                <ul className="department-list settings-list">
                                    {category.departments.map(dept => (
                                        <li key={dept.id}>
                                            <span className="department-name">{dept.name}</span>
                                            <div className="settings-controls">
                                                <div className="form-group hsn-group">
                                                    <label htmlFor={`hsn-${dept.id}`} className="sr-only">HSN for {dept.name}</label>
                                                    <input
                                                        id={`hsn-${dept.id}`} type="text" value={dept.hsn} placeholder="HSN Code"
                                                        onChange={(e) => onUpdateDepartment(category.id, dept.id, { hsn: e.target.value })}
                                                    />
                                                </div>
                                                <fieldset className="radio-group-inline" aria-label={`GST rate for ${dept.name}`}>
                                                    <legend className="sr-only">GST Rate for {dept.name}</legend>
                                                    <label><input type="radio" name={`gst-${dept.id}`} value={5} checked={dept.gst === 5} onChange={() => onUpdateDepartment(category.id, dept.id, { gst: 5 })} /> 5%</label>
                                                    <label><input type="radio" name={`gst-${dept.id}`} value={18} checked={dept.gst === 18} onChange={() => onUpdateDepartment(category.id, dept.id, { gst: 18 })} /> 18%</label>
                                                </fieldset>
                                                <button onClick={() => onDeleteDepartment(category.id, dept.id)} className="icon-button danger" aria-label={`Delete ${dept.name}`}>🗑️</button>
                                            </div>
                                        </li>
                                    ))}
                                    {category.departments.length === 0 && <p className="empty-state">No departments in this category yet.</p>}
                                </ul>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

// --- Product Attributes Page Component ---
const ATTRIBUTE_CONFIG: { [key in keyof ProductAttributes]: { label: string } } = {
    productNames: { label: 'Product Name' },
    brandNames: { label: 'Brand' },
    productCodes: { label: 'Product Code' },
    colors: { label: 'Color' },
    sizes: { label: 'Size' },
    patterns: { label: 'Pattern' },
    styles: { label: 'Style' },
    warranties: { label: 'Warranty' },
};

const ProductAttributesPage = ({ attributes, setAttributes }: {
    attributes: ProductAttributes;
    setAttributes: React.Dispatch<React.SetStateAction<ProductAttributes>>;
}) => {
    const [selectedAttribute, setSelectedAttribute] = useState<keyof ProductAttributes>(Object.keys(ATTRIBUTE_CONFIG)[0] as keyof ProductAttributes);
    const [newItem, setNewItem] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [editingItem, setEditingItem] = useState<string | null>(null);
    const [editValue, setEditValue] = useState('');

    const handleAddItem = (e: React.FormEvent) => {
        e.preventDefault();
        const trimmedItem = newItem.trim();
        if (trimmedItem && !attributes[selectedAttribute].map(i => i.toLowerCase()).includes(trimmedItem.toLowerCase())) {
            setAttributes(prev => ({
                ...prev,
                [selectedAttribute]: [...prev[selectedAttribute], trimmedItem].sort((a,b) => a.localeCompare(b))
            }));
            setNewItem('');
        } else if (trimmedItem) {
            alert(`This ${ATTRIBUTE_CONFIG[selectedAttribute].label.toLowerCase()} already exists.`);
        }
    };

    const handleDeleteItem = (itemToDelete: string) => {
        if (window.confirm(`Are you sure you want to delete "${itemToDelete}"? This cannot be undone.`)) {
            setAttributes(prev => {
                const newAttributes = { ...prev };
                const currentList = prev[selectedAttribute];
                newAttributes[selectedAttribute] = currentList.filter(item => item !== itemToDelete);
                return newAttributes;
            });
        }
    };

    const handleStartEdit = (item: string) => {
        setEditingItem(item);
        setEditValue(item);
    };

    const handleCancelEdit = () => {
        setEditingItem(null);
        setEditValue('');
    };

    const handleSaveEdit = (originalItem: string) => {
        const trimmedValue = editValue.trim();
        if (!trimmedValue) {
            alert('Attribute name cannot be empty.');
            return;
        }

        const lowerCaseList = attributes[selectedAttribute]
            .filter(i => i.toLowerCase() !== originalItem.toLowerCase())
            .map(i => i.toLowerCase());

        if (lowerCaseList.includes(trimmedValue.toLowerCase())) {
            alert(`This ${ATTRIBUTE_CONFIG[selectedAttribute].label.toLowerCase()} already exists.`);
            return;
        }

        setAttributes(prev => ({
            ...prev,
            [selectedAttribute]: prev[selectedAttribute]
                .map(item => item === originalItem ? trimmedValue : item)
                .sort((a,b) => a.localeCompare(b))
        }));

        handleCancelEdit();
    };

    const filteredItems = useMemo(() => {
        return attributes[selectedAttribute].filter(item => 
            item.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [attributes, selectedAttribute, searchTerm]);

    return (
        <div className="page-container">
            <div className="page-header">
                <h2>Manage Product Attributes</h2>
                <p>Add, edit, and remove shared attributes used across all your products.</p>
            </div>
            <div className="attribute-manager-layout">
                <div className="card attribute-controls">
                    <h3>Attribute Type</h3>
                    <div className="form-group">
                        <label htmlFor="attribute-select" className="sr-only">Select Attribute Type</label>
                        <select 
                            id="attribute-select"
                            value={selectedAttribute} 
                            onChange={e => {
                                setSelectedAttribute(e.target.value as keyof ProductAttributes);
                                setSearchTerm('');
                                setNewItem('');
                                handleCancelEdit();
                            }}
                        >
                            {Object.entries(ATTRIBUTE_CONFIG).map(([key, { label }]) => (
                                <option key={key} value={key}>{label}</option>
                            ))}
                        </select>
                    </div>
                    <form onSubmit={handleAddItem} className="add-attribute-form">
                        <div className="form-group">
                            <label htmlFor="new-attribute-item">Add New {ATTRIBUTE_CONFIG[selectedAttribute].label}</label>
                            <div className="input-with-button">
                                <input
                                    id="new-attribute-item"
                                    type="text"
                                    value={newItem}
                                    onChange={e => setNewItem(e.target.value)}
                                    placeholder={`e.g., "Red", "Large", etc.`}
                                    disabled={!!editingItem}
                                />
                                <button type="submit" className="primary-button" disabled={!!editingItem}>+</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div className="card attribute-list-container">
                    <div className="card-header">
                        <h3>{ATTRIBUTE_CONFIG[selectedAttribute].label} List ({filteredItems.length})</h3>
                        <div className="form-group search-bar">
                             <label htmlFor="search-attributes" className="sr-only">Search</label>
                             <input 
                                id="search-attributes"
                                type="search" 
                                placeholder="Search list..."
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                        </div>
                    </div>
                    
                    <ul className="attribute-list">
                        {filteredItems.length > 0 ? filteredItems.map(item => (
                            <li key={item}>
                                {editingItem === item ? (
                                    <form className="edit-attribute-form" onSubmit={e => { e.preventDefault(); handleSaveEdit(item); }}>
                                        <input
                                            type="text"
                                            value={editValue}
                                            onChange={(e) => setEditValue(e.target.value)}
                                            autoFocus
                                            onKeyDown={(e) => e.key === 'Escape' && handleCancelEdit()}
                                        />
                                        <div className="item-actions">
                                            <button type="submit" className="icon-button success" aria-label="Save changes">✔️</button>
                                            <button type="button" onClick={handleCancelEdit} className="icon-button" aria-label="Cancel edit">❌</button>
                                        </div>
                                    </form>
                                ) : (
                                    <>
                                        <span>{item}</span>
                                        <div className="item-actions">
                                            <button onClick={() => handleStartEdit(item)} className="icon-button" aria-label={`Edit ${item}`}>✏️</button>
                                            <button onClick={() => handleDeleteItem(item)} className="icon-button danger" aria-label={`Delete ${item}`}>🗑️</button>
                                        </div>
                                    </>
                                )}
                            </li>
                        )) : (
                            <li className="empty-state">No items found.</li>
                        )}
                    </ul>
                </div>
            </div>
        </div>
    );
};

// --- Text Highlight Component ---
const Highlight = ({ text, highlight }: { text: string; highlight: string; }) => {
    if (!highlight.trim()) {
        return <>{text}</>;
    }
    const regex = new RegExp(`(${highlight.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);
    return (
        <>
            {parts.map((part, i) =>
                part.toLowerCase() === highlight.toLowerCase() ? (
                    <strong key={i}>{part}</strong>
                ) : (
                    part
                )
            )}
        </>
    );
};

// --- Searchable Department Select Component ---
const SearchableDepartmentSelect = ({ label, name, value, onChange, categories, required = false }: {
    label: string;
    name: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => void;
    categories: Category[];
    required?: boolean;
}) => {
    const [query, setQuery] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);

    const selectedDepartment = useMemo(() => {
        if (!value) return null;
        for (const category of categories) {
            const dept = category.departments.find(d => d.id === value);
            if (dept) return dept;
        }
        return null;
    }, [value, categories]);
    
    useEffect(() => {
        if (selectedDepartment) {
            setQuery(selectedDepartment.name);
        } else {
            setQuery('');
        }
    }, [selectedDepartment]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
                if (selectedDepartment) {
                   setQuery(selectedDepartment.name);
                } else {
                   setQuery('');
                }
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [selectedDepartment]);

    const filteredCategories = useMemo(() => {
        if (!query || (selectedDepartment && query === selectedDepartment.name)) return categories;
        const lowerCaseQuery = query.toLowerCase();
        
        return categories
            .map(cat => ({
                ...cat,
                departments: cat.departments.filter(dept => dept.name.toLowerCase().includes(lowerCaseQuery))
            }))
            .filter(cat => cat.departments.length > 0);
    }, [query, categories, selectedDepartment]);

    const handleSelect = (deptId: string) => {
        const syntheticEvent = { target: { name, value: deptId } } as unknown as React.ChangeEvent<HTMLSelectElement>;
        onChange(syntheticEvent);
        setIsOpen(false);
    };

    return (
        <div className="form-group autocomplete-wrapper" ref={wrapperRef}>
            <label htmlFor={name}>{label}</label>
            <input
                type="text"
                id={name}
                value={query}
                onChange={e => {
                    setQuery(e.target.value);
                    if (!isOpen) setIsOpen(true);
                     if (e.target.value === '') { 
                        const syntheticEvent = { target: { name, value: '' } } as unknown as React.ChangeEvent<HTMLSelectElement>;
                        onChange(syntheticEvent);
                     }
                }}
                onFocus={() => setIsOpen(true)}
                placeholder="Type to search department..."
                required={required && !value}
                autoComplete="off"
            />
            {isOpen && (
                <ul className="suggestions-list" onMouseDown={e => e.preventDefault()}>
                    {filteredCategories.length > 0 ? filteredCategories.map(cat => (
                        <React.Fragment key={cat.id}>
                           <li className="suggestion-category">{cat.name}</li>
                           {cat.departments.map(dept => (
                               <li key={dept.id} onClick={() => handleSelect(dept.id)}>
                                   {dept.name}
                               </li>
                           ))}
                        </React.Fragment>
                    )) : <li className="suggestion-item-empty">No results found</li>}
                </ul>
            )}
        </div>
    );
};

// --- Autocomplete Input Component ---
const AutocompleteInput = ({ label, name, value, onChange, options, required = false, ...props }: {
    label: string;
    name: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    options: string[];
    required?: boolean;
    [key: string]: any;
}) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);
    
    const handleBlur = () => {
        const currentValue = value.trim();
        if (!currentValue) return;

        const match = options.find(opt => opt.toLowerCase() === currentValue.toLowerCase());
        if (match && match !== currentValue) {
            const syntheticEvent = { target: { name, value: match } } as React.ChangeEvent<HTMLInputElement>;
            onChange(syntheticEvent);
        }
    };
    
    const onSuggestionClick = (suggestion: string) => {
        const syntheticEvent = { target: { name, value: suggestion } } as React.ChangeEvent<HTMLInputElement>;
        onChange(syntheticEvent);
        setShowSuggestions(false);
    };

    const suggestions = useMemo(() => {
        if (!value) return options;
        const lowerCaseValue = value.toLowerCase();
        return options.filter(opt => opt.toLowerCase().includes(lowerCaseValue));
    }, [options, value]);

    return (
        <div className="form-group autocomplete-wrapper" ref={wrapperRef}>
            <label htmlFor={name}>{label}</label>
            <input
                type="text"
                id={name}
                name={name}
                value={value}
                onChange={onChange}
                onFocus={() => setShowSuggestions(true)}
                onBlur={handleBlur}
                required={required}
                autoComplete="off"
                {...props}
            />
            {showSuggestions && options.length > 0 && (
                <ul className="suggestions-list" onMouseDown={e => e.preventDefault()}>
                    {suggestions.length > 0 ? suggestions.map((suggestion, index) => (
                        <li key={index} onClick={() => onSuggestionClick(suggestion)}>
                            <Highlight text={suggestion} highlight={value} />
                        </li>
                    )) : (
                        <li className="suggestion-item-empty">No matches found</li>
                    )}
                </ul>
            )}
        </div>
    );
};

// --- Multi-select Autocomplete Input Component ---
const MultiAutocompleteInput = ({ label, values, onChange, options, ...props }: {
    label: string;
    values: string[];
    onChange: (newValues: string[]) => void;
    options: string[];
    [key: string]: any;
}) => {
    const [inputValue, setInputValue] = useState('');
    const [showSuggestions, setShowSuggestions] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const addValue = (valueToAdd: string) => {
        const trimmedValue = valueToAdd.trim();
        if (trimmedValue && !values.map(v => v.toLowerCase()).includes(trimmedValue.toLowerCase())) {
            onChange([...values, trimmedValue]);
        }
        setInputValue('');
        setShowSuggestions(false);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter' && inputValue) {
            e.preventDefault();
            const trimmedValue = inputValue.trim();
            if(!trimmedValue) return;
            
            const match = options.find(s => s.toLowerCase() === trimmedValue.toLowerCase());
            addValue(match || trimmedValue);
        }
    };

    const removeValue = (valueToRemove: string) => {
        onChange(values.filter(v => v !== valueToRemove));
    };

    const availableOptions = useMemo(() => {
        const lowerCasedValues = values.map(v => v.toLowerCase());
        return options.filter(opt => !lowerCasedValues.includes(opt.toLowerCase()));
    }, [options, values]);
    
    const suggestions = useMemo(() => {
        if (!inputValue) return availableOptions;
        const lowerCaseValue = inputValue.toLowerCase();
        return availableOptions.filter(opt => opt.toLowerCase().includes(lowerCaseValue));
    }, [availableOptions, inputValue]);


    return (
        <div className="form-group autocomplete-wrapper" ref={wrapperRef}>
            <label>{label}</label>
            <div className="multi-autocomplete-container" onClick={() => inputRef.current?.focus()}>
                {values.map(value => (
                    <span key={value} className="tag">
                        {value}
                        <button type="button" className="tag-remove" onClick={() => removeValue(value)}>&times;</button>
                    </span>
                ))}
                <input
                    ref={inputRef}
                    type="text"
                    value={inputValue}
                    onChange={e => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    onFocus={() => setShowSuggestions(true)}
                    className="multi-autocomplete-input"
                    {...props}
                />
            </div>
            {showSuggestions && availableOptions.length > 0 && (
                <ul className="suggestions-list" onMouseDown={e => e.preventDefault()}>
                    {suggestions.length > 0 ? suggestions.map((suggestion, index) => (
                        <li key={index} onClick={() => addValue(suggestion)}>
                            <Highlight text={suggestion} highlight={inputValue} />
                        </li>
                    )) : (
                        <li className="suggestion-item-empty">No matches found</li>
                    )}
                </ul>
            )}
        </div>
    );
};

// --- Color & Product Code Paired Input Component ---
type ColorCodePair = { id: string; color: string; productCode: string };

const ColorProductCodePairInput = ({ label, pairs, setPairs, colorOptions, codeOptions, disabled = {} }: {
    label: string;
    pairs: ColorCodePair[];
    setPairs: (pairs: ColorCodePair[]) => void;
    colorOptions: string[];
    codeOptions: string[];
    disabled?: { color?: boolean; productCode?: boolean; addRemove?: boolean; };
}) => {
    const handleAddPair = () => {
        setPairs([...pairs, { id: crypto.randomUUID(), color: '', productCode: '' }]);
    };

    const handleRemovePair = (id: string) => {
        if (pairs.length > 1) {
            setPairs(pairs.filter(p => p.id !== id));
        }
    };

    const handleUpdatePair = (id: string, field: 'color' | 'productCode', value: string) => {
        setPairs(pairs.map(p => p.id === id ? { ...p, [field]: value } : p));
    };

    return (
        <div className="form-group form-group-span-2">
            <label>{label}</label>
            <div className="pair-input-container">
                {pairs.map((pair, index) => (
                    <div key={pair.id} className="pair-input-row">
                        <AutocompleteInput 
                            label="Color"
                            name={`color-${pair.id}`}
                            value={pair.color}
                            onChange={(e) => handleUpdatePair(pair.id, 'color', e.target.value)}
                            options={colorOptions}
                            placeholder="Select or type color"
                            aria-label={`Color for item ${index + 1}`}
                            disabled={disabled.color}
                        />
                         <AutocompleteInput 
                            label="Product Code"
                            name={`code-${pair.id}`}
                            value={pair.productCode}
                            onChange={(e) => handleUpdatePair(pair.id, 'productCode', e.target.value)}
                            options={codeOptions}
                            placeholder="Select or type code"
                            aria-label={`Product Code for item ${index + 1}`}
                            disabled={disabled.productCode}
                        />
                        {!disabled.addRemove && (
                            <button 
                                type="button" 
                                onClick={() => handleRemovePair(pair.id)} 
                                className="icon-button danger remove-pair-button" 
                                aria-label={`Remove item ${index + 1}`}
                                disabled={pairs.length <= 1}
                            >
                                &times;
                            </button>
                        )}
                    </div>
                ))}
                {!disabled.addRemove && (
                    <div className="pair-input-actions">
                         <button type="button" onClick={handleAddPair} className="secondary-button">Add another color/code pair</button>
                    </div>
                )}
            </div>
        </div>
    );
};


// --- Purchase Entry Page Component ---
type PurchaseFormState = Omit<PurchaseEntry, 'id' | 'quantity' | 'landingRate' | 'mrp' | 'sellingPrice' | 'marginPercentage' | 'discountPercentage' | 'color' | 'size' | 'productCode'> & {
    quantity: string;
    landingRate: string;
    mrp: string;
    sellingPrice: string;
    marginPercentage: string;
    discountPercentage: string;
    size: string[];
    colorCodePairs: ColorCodePair[];
};

type SetItem = {
    id: string;
    size: string;
    mrp: string;
    marginPercentage: string;
    discountPercentage: string;
    sellingPrice: string;
};

const PurchaseEntryPage = ({ 
    categories, departments, entries, productAttributes, 
    onAddEntry, onUpdateEntry, onDeleteEntry, onClearAllEntries, onDeleteSelectedEntries,
    editingEntryId, onStartEdit, onCancelEdit, onViewEntry,
    selectedEntryIds, setSelectedEntryIds
}: {
    categories: Category[];
    departments: Department[];
    entries: PurchaseEntry[];
    productAttributes: ProductAttributes;
    onAddEntry: (entry: Omit<PurchaseEntry, 'id'>) => void;
    onUpdateEntry: (id: string, updatedEntryData: Partial<Omit<PurchaseEntry, 'id'>>) => void;
    onDeleteEntry: (id: string) => void;
    onClearAllEntries: () => void;
    onDeleteSelectedEntries: (ids: Set<string>) => void;
    editingEntryId: string | null;
    onStartEdit: (id: string) => void;
    onCancelEdit: () => void;
    onViewEntry: (entry: PurchaseEntry) => void;
    selectedEntryIds: Set<string>;
    setSelectedEntryIds: React.Dispatch<React.SetStateAction<Set<string>>>;
}) => {
    const initialFormState: PurchaseFormState = {
        departmentId: '', productName: '', hsn: '', brandName: '', demBarcode: '',
        size: [], warranty: '', pattern: '', style: '',
        quantity: '', landingRate: '', mrp: '', sellingPrice: '', marginPercentage: '', discountPercentage: '',
        colorCodePairs: [{ id: crypto.randomUUID(), color: '', productCode: '' }],
    };

    const initialSetItemsState: SetItem[] = [{ id: crypto.randomUUID(), size: '', mrp: '', marginPercentage: '', discountPercentage: '', sellingPrice: '' }];

    const [formState, setFormState] = useState<PurchaseFormState>(initialFormState);
    const [isSetMode, setIsSetMode] = useState(false);
    const [setItems, setSetItems] = useState<SetItem[]>(initialSetItemsState);
    const [editedEntries, setEditedEntries] = useState<Record<string, Partial<PurchaseEntry>>>({});

    const isEditMode = !!editingEntryId;

    useEffect(() => {
        if (editingEntryId) {
            setIsSetMode(false); // Disable set mode when editing
            const entryToEdit = entries.find(e => e.id === editingEntryId);
            if (entryToEdit) {
                const { id, ...formData } = entryToEdit;
                setFormState({
                    ...formData,
                    quantity: String(formData.quantity),
                    landingRate: String(formData.landingRate),
                    mrp: String(formData.mrp),
                    sellingPrice: String(formData.sellingPrice),
                    marginPercentage: String(formData.marginPercentage),
                    discountPercentage: String(formData.discountPercentage),
                    size: formData.size ? [formData.size] : [],
                    colorCodePairs: [{ id: crypto.randomUUID(), color: formData.color, productCode: formData.productCode }],
                });
            }
        } else {
            setFormState(initialFormState);
        }
    }, [editingEntryId, entries]);

    useEffect(() => {
        if (formState.departmentId && !isEditMode) {
            const selectedDept = departments.find(d => d.id === formState.departmentId);
            if (selectedDept) {
                setFormState(prev => ({ ...prev, hsn: selectedDept.hsn || '' }));
            }
        }
    }, [formState.departmentId, departments, isEditMode]);

    const { quantity, landingRate, departmentId } = formState;

    const calculations = useMemo(() => {
        const numQuantity = parseFloat(quantity) || 0;
        const numLandingRate = parseFloat(landingRate) || 0;
        const taxableAmount = numQuantity * numLandingRate;
        const selectedDept = departments.find(d => d.id === departmentId);
        const gstRate = selectedDept ? selectedDept.gst : 0;
        const gstAmount = taxableAmount * (gstRate / 100);
        const totalAmount = taxableAmount + gstAmount;
        return { taxableAmount, gstRate, gstAmount, totalAmount };
    }, [quantity, landingRate, departmentId, departments]);

    const setCalculations = useMemo(() => {
        const totalLandingRateForSet = parseFloat(formState.landingRate) || 0;
        const totalMrp = setItems.reduce((sum, item) => sum + (parseFloat(item.mrp) || 0), 0);
        
        const itemsWithCalculations = setItems.map(item => {
            const itemMrp = parseFloat(item.mrp) || 0;
            const proportion = totalMrp > 0 ? itemMrp / totalMrp : 0;
            const calculatedLandingRate = totalLandingRateForSet * proportion;
            return {
                ...item,
                calculatedLandingRate,
            };
        });

        const totalCalculatedLanding = itemsWithCalculations.reduce((sum, item) => sum + item.calculatedLandingRate, 0);

        return { itemsWithCalculations, totalMrp, totalCalculatedLanding };

    }, [formState.landingRate, setItems]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormState(prev => ({ ...prev, [name]: value }));
    };
    
    const handleMultiChange = (name: 'size', values: string[]) => {
        setFormState(prev => ({ ...prev, [name]: values }));
    };

    const handlePricingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        
        setFormState(prev => {
            const newState = { ...prev, [name]: value };

            const landingRate = parseFloat(newState.landingRate) || 0;
            const mrp = parseFloat(newState.mrp) || 0;
            const marginPercentage = parseFloat(newState.marginPercentage) || 0;
            const discountPercentage = parseFloat(newState.discountPercentage) || 0;

            const getNewStateValue = (val: number | string) => (val === '' || val === 0) ? '' : String(val);

            switch (name) {
                case 'landingRate':
                case 'marginPercentage':
                    if (landingRate > 0 && marginPercentage >= 0) {
                        const newMrp = landingRate * (1 + marginPercentage / 100);
                        newState.mrp = getNewStateValue(Math.round(newMrp));
                        const newSellingPrice = Math.round(newMrp) * (1 - (parseFloat(newState.discountPercentage) || 0) / 100);
                        newState.sellingPrice = getNewStateValue(Math.round(newSellingPrice));
                    }
                    break;

                case 'mrp':
                    if (landingRate > 0 && mrp > 0) {
                        const newMargin = ((mrp / landingRate) - 1) * 100;
                        newState.marginPercentage = getNewStateValue(parseFloat(newMargin.toFixed(2)));
                    }
                    if (mrp > 0 && discountPercentage >= 0) {
                        const newSellingPrice = mrp * (1 - discountPercentage / 100);
                        newState.sellingPrice = getNewStateValue(Math.round(newSellingPrice));
                    }
                    break;
                
                case 'discountPercentage':
                    if (mrp > 0 && discountPercentage >= 0) {
                        const newSellingPrice = mrp * (1 - discountPercentage / 100);
                        newState.sellingPrice = getNewStateValue(Math.round(newSellingPrice));
                    }
                    break;

                case 'sellingPrice':
                    const sellingPrice = parseFloat(newState.sellingPrice) || 0;
                     if (mrp > 0 && sellingPrice >= 0) {
                        const newDiscount = (1 - (sellingPrice / mrp)) * 100;
                        newState.discountPercentage = getNewStateValue(parseFloat(Math.max(0, newDiscount).toFixed(2)));
                    }
                    break;
            }
            return newState;
        });
    };

    const handleSetItemChange = (id: string, field: keyof SetItem, value: string) => {
        setSetItems(prevItems => {
            return prevItems.map(item => {
                if (item.id !== id) return item;

                const updatedItem = { ...item, [field]: value };
                
                const mrp = parseFloat(updatedItem.mrp) || 0;
                const marginPercentage = parseFloat(updatedItem.marginPercentage) || 0;
                
                if (field === 'mrp' || field === 'marginPercentage' || field === 'discountPercentage' || field === 'sellingPrice') {
                    const { calculatedLandingRate } = setCalculations.itemsWithCalculations.find(i => i.id === id) || { calculatedLandingRate: 0 };
                    
                    const getNewStateValue = (val: number | string) => (val === '' || val === 0) ? '' : String(val);

                    switch(field) {
                        case 'marginPercentage':
                            if (calculatedLandingRate > 0 && marginPercentage >= 0) {
                                const newMrp = calculatedLandingRate * (1 + marginPercentage / 100);
                                updatedItem.mrp = getNewStateValue(Math.round(newMrp));
                                const newSellingPrice = Math.round(newMrp) * (1 - (parseFloat(updatedItem.discountPercentage) || 0) / 100);
                                updatedItem.sellingPrice = getNewStateValue(Math.round(newSellingPrice));
                            }
                            break;
                        case 'mrp':
                             if (calculatedLandingRate > 0 && mrp > 0) {
                                const newMargin = ((mrp / calculatedLandingRate) - 1) * 100;
                                updatedItem.marginPercentage = getNewStateValue(parseFloat(newMargin.toFixed(2)));
                            }
                            if (mrp > 0) {
                                const newSellingPrice = mrp * (1 - (parseFloat(updatedItem.discountPercentage) || 0) / 100);
                                updatedItem.sellingPrice = getNewStateValue(Math.round(newSellingPrice));
                            }
                            break;
                         case 'discountPercentage':
                            if (mrp > 0) {
                                const newSellingPrice = mrp * (1 - (parseFloat(updatedItem.discountPercentage) || 0) / 100);
                                updatedItem.sellingPrice = getNewStateValue(Math.round(newSellingPrice));
                            }
                            break;
                         case 'sellingPrice':
                             const sellingPrice = parseFloat(updatedItem.sellingPrice) || 0;
                             if (mrp > 0 && sellingPrice >= 0) {
                                const newDiscount = (1 - (sellingPrice / mrp)) * 100;
                                updatedItem.discountPercentage = getNewStateValue(parseFloat(Math.max(0, newDiscount).toFixed(2)));
                            }
                            break;
                    }
                }

                return updatedItem;
            });
        });
    };

    const addSetItem = () => {
        setSetItems(prev => [...prev, { id: crypto.randomUUID(), size: '', mrp: '', marginPercentage: '', discountPercentage: '', sellingPrice: '' }]);
    };

    const removeSetItem = (id: string) => {
        setSetItems(prev => prev.filter(item => item.id !== id));
    };

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if(!formState.departmentId) {
            alert('Please select a department.'); return;
        }
        if(!formState.productName.trim()) {
            alert('Please enter a Product Name.'); return;
        }
        
        if (isEditMode && editingEntryId) {
            const numQuantity = parseFloat(formState.quantity);
            const numLandingRate = parseFloat(formState.landingRate);
            if(isNaN(numQuantity) || numQuantity <= 0 || isNaN(numLandingRate) || numLandingRate <= 0){
                alert('Quantity and Landing Rate must be valid numbers greater than zero.'); return;
            }
            const { colorCodePairs, ...restOfFormState } = formState;
            const pair = colorCodePairs[0] || { color: '', productCode: '' };

            const updatedEntryData: Omit<PurchaseEntry, 'id'> = {
                ...restOfFormState,
                quantity: numQuantity,
                landingRate: numLandingRate,
                mrp: parseFloat(formState.mrp) || 0,
                sellingPrice: parseFloat(formState.sellingPrice) || 0,
                marginPercentage: parseFloat(formState.marginPercentage) || 0,
                discountPercentage: parseFloat(formState.discountPercentage) || 0,
                color: pair.color,
                productCode: pair.productCode,
                size: formState.size[0] || '',
            };
            onUpdateEntry(editingEntryId, updatedEntryData);
        } else if (isSetMode) {
            // --- SET MODE SUBMISSION ---
            const numSets = parseFloat(formState.quantity) || 0;
            const totalLandingRate = parseFloat(formState.landingRate) || 0;
             if (numSets <= 0 || totalLandingRate <= 0) {
                alert('Number of Sets and Total Landing Rate must be greater than zero.');
                return;
            }
            if (setItems.some(item => !item.size.trim() || !(parseFloat(item.mrp) > 0))) {
                alert('Each item in the set must have a Size and a valid MRP.');
                return;
            }

            const { itemsWithCalculations, totalCalculatedLanding } = setCalculations;

             if (Math.abs(totalCalculatedLanding - totalLandingRate) > 0.01 * setItems.length) {
                if (!window.confirm(`The sum of calculated landing rates (₹${totalCalculatedLanding.toFixed(2)}) doesn't exactly match the total entered (₹${totalLandingRate.toFixed(2)}) due to rounding. Do you want to proceed?`)) {
                    return;
                }
            }
            
            let pairs = formState.colorCodePairs.filter(p => p.color.trim());
            if (pairs.length === 0) {
                pairs.push({ id: '', color: '', productCode: '' });
            }
            
            const { colorCodePairs, ...baseEntryData } = formState;

            itemsWithCalculations.forEach(item => {
                for (const pair of pairs) {
                    const newEntryData: Omit<PurchaseEntry, 'id'> = {
                        ...baseEntryData,
                        productCode: pair.productCode,
                        color: pair.color,
                        size: item.size,
                        quantity: numSets,
                        landingRate: item.calculatedLandingRate,
                        mrp: parseFloat(item.mrp) || 0,
                        sellingPrice: parseFloat(item.sellingPrice) || 0,
                        marginPercentage: parseFloat(item.marginPercentage) || 0,
                        discountPercentage: parseFloat(item.discountPercentage) || 0,
                    };
                    onAddEntry(newEntryData);
                }
            });

        } else {
             // --- STANDARD MODE SUBMISSION ---
            const numQuantity = parseFloat(formState.quantity);
            const numLandingRate = parseFloat(formState.landingRate);
            if(isNaN(numQuantity) || numQuantity <= 0 || isNaN(numLandingRate) || numLandingRate <= 0){
                alert('Quantity and Landing Rate must be valid numbers greater than zero.'); return;
            }
            const { colorCodePairs, ...restOfFormState } = formState;

            const baseEntryData = {
                ...restOfFormState,
                quantity: numQuantity,
                landingRate: numLandingRate,
                mrp: parseFloat(formState.mrp) || 0,
                sellingPrice: parseFloat(formState.sellingPrice) || 0,
                marginPercentage: parseFloat(formState.marginPercentage) || 0,
                discountPercentage: parseFloat(formState.discountPercentage) || 0,
            };
            
            let pairs = formState.colorCodePairs.filter(p => p.color.trim() || p.productCode.trim());
            if (pairs.length === 0) {
                 pairs.push({ id: crypto.randomUUID(), color: '', productCode: '' });
            }
            const sizes = formState.size.length ? formState.size : [''];
            
            for (const pair of pairs) {
                for (const size of sizes) {
                    const newEntryData = { ...baseEntryData, color: pair.color, productCode: pair.productCode, size };
                    onAddEntry(newEntryData);
                }
            }
        }
        setFormState(initialFormState);
        setSetItems(initialSetItemsState);
        setIsSetMode(false);
    };

    const getDepartmentInfo = (id: string, type: 'name' | 'gst') => {
        const dept = departments.find(d => d.id === id);
        if (!dept) return type === 'name' ? 'N/A' : 0;
        return type === 'name' ? dept.name : dept.gst;
    };
    
    // --- Table Inline Editing Handlers ---
    const handleTableInputChange = (id: string, field: keyof PurchaseEntry, value: string) => {
        setEditedEntries(prev => {
            const originalEntry = entries.find(e => e.id === id)!;
            
            const existingChanges = prev[id] || {};
            const newChanges: Partial<PurchaseEntry> = { ...existingChanges };

            const numValue = field === 'quantity' ? parseInt(value, 10) : parseFloat(value);
            if (isNaN(numValue) && value !== '') {
                return prev; // Don't update for invalid non-empty strings
            }
            (newChanges as any)[field] = isNaN(numValue) ? '' : numValue;

            const mergedEntry = { ...originalEntry, ...newChanges };

            switch (field) {
                case 'landingRate':
                    if (mergedEntry.landingRate > 0 && mergedEntry.marginPercentage >= 0) {
                        const newMrp = mergedEntry.landingRate * (1 + mergedEntry.marginPercentage / 100);
                        mergedEntry.mrp = Math.round(newMrp);
                        newChanges.mrp = mergedEntry.mrp;

                        const newSellingPrice = mergedEntry.mrp * (1 - mergedEntry.discountPercentage / 100);
                        mergedEntry.sellingPrice = Math.round(newSellingPrice);
                        newChanges.sellingPrice = mergedEntry.sellingPrice;
                    }
                    break;
                case 'mrp':
                    if (mergedEntry.landingRate > 0 && mergedEntry.mrp > 0) {
                        const newMargin = ((mergedEntry.mrp / mergedEntry.landingRate) - 1) * 100;
                        mergedEntry.marginPercentage = parseFloat(newMargin.toFixed(2));
                        newChanges.marginPercentage = mergedEntry.marginPercentage;
                    }
                    if (mergedEntry.mrp >= 0) {
                        const newSellingPrice = mergedEntry.mrp * (1 - mergedEntry.discountPercentage / 100);
                        mergedEntry.sellingPrice = Math.round(newSellingPrice);
                        newChanges.sellingPrice = mergedEntry.sellingPrice;
                    }
                    break;
                case 'sellingPrice':
                    if (mergedEntry.mrp > 0 && mergedEntry.sellingPrice >= 0) {
                        const newDiscount = (1 - (mergedEntry.sellingPrice / mergedEntry.mrp)) * 100;
                        mergedEntry.discountPercentage = parseFloat(Math.max(0, newDiscount).toFixed(2));
                        newChanges.discountPercentage = mergedEntry.discountPercentage;
                    }
                    break;
            }

            for (const key in newChanges) {
                const k = key as keyof PurchaseEntry;
                if (String(newChanges[k]) === String(originalEntry[k])) {
                    delete newChanges[k];
                }
            }
            
            const newEditedEntries = { ...prev };
            if (Object.keys(newChanges).length > 0) {
                newEditedEntries[id] = newChanges;
            } else {
                delete newEditedEntries[id];
            }
            
            return newEditedEntries;
        });
    };

    const handleSaveChanges = () => {
        Object.entries(editedEntries).forEach(([id, changes]) => {
            const validChanges: Partial<PurchaseEntry> = {};
            // FIX: The right-hand side of a 'for...in' statement must be of type 'any' or an object type.
            // Due to type pollution in `editedEntries`, `changes` is inferred as `unknown`.
            // Casting `changes` to `any` allows the loop to proceed.
            for(const key in (changes as any)) {
                const k = key as keyof PurchaseEntry;
                const value = (changes as any)[k];
                if(value !== '' && !isNaN(Number(value))) {
                     (validChanges as any)[k] = Number(value);
                }
            }
            if(Object.keys(validChanges).length > 0) {
                onUpdateEntry(id, validChanges);
            }
        });
        setEditedEntries({});
    };

    const handleDiscardChanges = () => {
        setEditedEntries({});
    };

    const handleExport = () => {
        const entriesToExport = selectedEntryIds.size > 0
            ? entries.filter(entry => selectedEntryIds.has(entry.id))
            : entries;

        if (entriesToExport.length === 0) {
            alert("No entries to export.");
            return;
        }

        const headers = [
            'Department', 'Section', 'Division', 'Unit Name', 'Item Name', 'Short Name', 'Scan Unit', 'Tax Name',
            'Quantity', 'Rate', 'Sales Price', 'Retail Price', 'Online Mrp', 'Listed Mrp', 'Discounted Rate',
            'Taxable Rate', 'OEM Barcode', 'Brand', 'Product Cod', 'Color', 'Type', 'Pattern', 'Size', 'Style',
            'Warranty', 'Promo', 'Category1', 'Category2', 'Category3', 'Category4', 'Category5', '', '', 'HSN Code'
        ];

        const escapeCsvCell = (cell: any): string => {
            const cellStr = String(cell ?? '');
            if (cellStr.includes(',') || cellStr.includes('"') || cellStr.includes('\n')) {
                return `"${cellStr.replace(/"/g, '""')}"`;
            }
            return cellStr;
        };
        
        const rows = entriesToExport.map(entry => {
            const department = departments.find(d => d.id === entry.departmentId);
            const category = categories.find(c => c.departments.some(d => d.id === entry.departmentId));
            const singleItemTaxableRate = entry.landingRate * (1 + (department?.gst || 0) / 100);
            
            const rowData = [
                department?.name || '',
                category?.name || '',
                'Roshan Bags',
                'PCS',
                entry.productName,
                '', // Short Name
                1,  // Scan Unit
                `GST ${department?.gst || 0}% @ ${department?.gst || 0}%`,
                entry.quantity,
                entry.landingRate,
                entry.sellingPrice,
                entry.sellingPrice, // Retail Price
                entry.mrp,
                entry.mrp, // Listed Mrp
                entry.landingRate, // Discounted Rate
                singleItemTaxableRate,
                entry.demBarcode, // OEM Barcode
                entry.brandName,
                entry.productCode,
                entry.color,
                '', // Type
                entry.pattern,
                entry.size, // Size
                '', // Style
                entry.warranty,
                '', // Promo
                '', // Category1
                '', // Category2
                '', // Category3
                '', // Category4
                '', // Category5
                '', // Empty Column AF
                '', // Empty Column AG
                entry.hsn,
            ];
            
            return rowData.map(escapeCsvCell).join(',');
        });

        const csvContent = [headers.join(','), ...rows].join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-t;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'purchase_entries.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleSelectOne = (id: string, isChecked: boolean) => {
        setSelectedEntryIds(prev => {
            const newSet = new Set(prev);
            if (isChecked) {
                newSet.add(id);
            } else {
                newSet.delete(id);
            }
            return newSet;
        });
    };

    const handleSelectAll = (isChecked: boolean) => {
        if (isChecked) {
            setSelectedEntryIds(new Set(entries.map(e => e.id)));
        } else {
            setSelectedEntryIds(new Set());
        }
    };

    const allSelected = entries.length > 0 && selectedEntryIds.size === entries.length;
    const hasPendingChanges = Object.keys(editedEntries).length > 0;

    return (
        <div className="page-container">
            <div className="card">
                <h2>{isEditMode ? 'Edit Purchase Entry' : 'New Purchase Entry'}</h2>
                <form onSubmit={handleSubmit} className="entry-form">
                    <div className="form-section">
                        <h3>Product Details</h3>
                        <div className="form-grid">
                            <SearchableDepartmentSelect label="Department *" name="departmentId" value={formState.departmentId} onChange={handleChange} categories={categories} required />
                            <AutocompleteInput label="Product Name *" name="productName" value={formState.productName} onChange={handleChange} options={productAttributes.productNames} required />
                            <div className="form-group"><label htmlFor="hsn">HSN</label><input id="hsn" name="hsn" type="text" value={formState.hsn} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="gstDisplay">GST (%)</label><input id="gstDisplay" name="gstDisplay" type="text" value={calculations.gstRate} readOnly disabled /></div>
                            <AutocompleteInput label="Brand Name" name="brandName" value={formState.brandName} onChange={handleChange} options={productAttributes.brandNames} />
                            <div className="form-group"><label htmlFor="demBarcode">DEM Barcode</label><input id="demBarcode" name="demBarcode" type="text" value={formState.demBarcode} onChange={handleChange} /></div>
                            
                            <ColorProductCodePairInput 
                                label="Color & Product Code"
                                pairs={formState.colorCodePairs}
                                setPairs={(pairs) => setFormState(prev => ({ ...prev, colorCodePairs: pairs }))}
                                colorOptions={productAttributes.colors}
                                codeOptions={productAttributes.productCodes}
                                disabled={isEditMode ? { productCode: true, addRemove: true, color: false } : {}}
                            />
                            
                            {isSetMode ? 
                                <div className="form-group"><label>Size</label><input type="text" value="Defined in items below" readOnly disabled /></div>
                                :
                                <MultiAutocompleteInput label="Size" values={formState.size} onChange={(v) => handleMultiChange('size', v)} options={productAttributes.sizes} placeholder="Type or select sizes..."/>
                            }
                            <AutocompleteInput label="Warranty" name="warranty" value={formState.warranty} onChange={handleChange} options={productAttributes.warranties} placeholder="e.g., 1 year" />
                        </div>
                    </div>
                    <div className="form-section">
                        <div className="section-header">
                            <h3>Pricing & Quantity</h3>
                            {!isEditMode && (
                               <div className="form-switch-container">
                                    <label htmlFor="setModeSwitch" className="form-switch-label">Set Entry Mode</label>
                                    <label className="form-switch">
                                        <input type="checkbox" id="setModeSwitch" checked={isSetMode} onChange={e => setIsSetMode(e.target.checked)} />
                                        <span className="slider round"></span>
                                    </label>
                                </div>
                            )}
                        </div>
                        
                        {!isSetMode ? (
                          <div className="form-grid">
                              <div className="form-group"><label htmlFor="quantity">Quantity *</label><input id="quantity" name="quantity" type="number" min="0" value={formState.quantity} onChange={handlePricingChange} placeholder="e.g., 10" required/></div>
                              <div className="form-group"><label htmlFor="landingRate">Landing Rate *</label><input id="landingRate" name="landingRate" type="number" min="0" step="0.01" value={formState.landingRate} onChange={handlePricingChange} placeholder="e.g., 500.00" required/></div>
                              <div className="form-group"><label htmlFor="marginPercentage">Margin (%)</label><input id="marginPercentage" name="marginPercentage" type="number" min="0" step="0.01" value={formState.marginPercentage} onChange={handlePricingChange} placeholder="e.g., 50.00" /></div>
                              <div className="form-group"><label htmlFor="mrp">MRP</label><input id="mrp" name="mrp" type="number" min="0" step="1" value={formState.mrp} onChange={handlePricingChange} placeholder="Auto-calculated" /></div>
                              <div className="form-group"><label htmlFor="discountPercentage">Discount (%)</label><input id="discountPercentage" name="discountPercentage" type="number" min="0" max="100" step="0.01" value={formState.discountPercentage} onChange={handlePricingChange} placeholder="e.g., 10.00" /></div>
                              <div className="form-group"><label htmlFor="sellingPrice">Selling Price</label><input id="sellingPrice" name="sellingPrice" type="number" min="0" step="1" value={formState.sellingPrice} onChange={handlePricingChange} placeholder="Auto-calculated" /></div>
                          </div>
                        ) : (
                          <div className="set-mode-container">
                                <div className="form-grid">
                                    <div className="form-group"><label htmlFor="quantity">Number of Sets *</label><input id="quantity" name="quantity" type="number" min="1" step="1" value={formState.quantity} onChange={handleChange} placeholder="e.g., 1" required/></div>
                                    <div className="form-group"><label htmlFor="landingRate">Total Landing Rate (for set) *</label><input id="landingRate" name="landingRate" type="number" min="0" step="0.01" value={formState.landingRate} onChange={handleChange} placeholder="e.g., 20000.00" required/></div>
                                </div>
                                <div className="set-items-container">
                                    <h4>Individual Items in Set</h4>
                                    {setCalculations.itemsWithCalculations.map((item, index) => (
                                        <div key={item.id} className="set-item-row">
                                            <AutocompleteInput label="Size *" name={`size-${item.id}`} value={item.size} onChange={e => handleSetItemChange(item.id, 'size', e.target.value)} options={productAttributes.sizes} required />
                                            <div className="form-group"><label htmlFor={`mrp-${item.id}`}>MRP *</label><input id={`mrp-${item.id}`} name="mrp" type="number" min="0" step="1" value={item.mrp} onChange={e => handleSetItemChange(item.id, 'mrp', e.target.value)} placeholder="e.g., 8000" required /></div>
                                            <div className="form-group"><label htmlFor={`landingRate-${item.id}`}>Calculated Landing</label><input id={`landingRate-${item.id}`} type="text" value={item.calculatedLandingRate.toFixed(2)} readOnly disabled /></div>
                                            <div className="form-group"><label htmlFor={`margin-${item.id}`}>Margin (%)</label><input id={`margin-${item.id}`} type="number" value={item.marginPercentage} onChange={e => handleSetItemChange(item.id, 'marginPercentage', e.target.value)} /></div>
                                            <div className="form-group"><label htmlFor={`discount-${item.id}`}>Discount (%)</label><input id={`discount-${item.id}`} type="number" value={item.discountPercentage} onChange={e => handleSetItemChange(item.id, 'discountPercentage', e.target.value)} /></div>
                                            <div className="form-group"><label htmlFor={`selling-${item.id}`}>Selling Price</label><input id={`selling-${item.id}`} type="number" value={item.sellingPrice} onChange={e => handleSetItemChange(item.id, 'sellingPrice', e.target.value)} /></div>
                                            <button type="button" onClick={() => removeSetItem(item.id)} className="icon-button danger remove-set-item" aria-label="Remove item" disabled={setItems.length <= 1}>&times;</button>
                                        </div>
                                    ))}
                                     <div className="set-items-actions">
                                        <button type="button" onClick={addSetItem} className="secondary-button">Add Item to Set</button>
                                    </div>
                                    <div className="set-summary">
                                        <strong>Total MRP:</strong> ₹{setCalculations.totalMrp.toFixed(2)} | 
                                        <strong> Total Calculated Landing:</strong> ₹{setCalculations.totalCalculatedLanding.toFixed(2)}
                                    </div>
                                </div>
                          </div>
                        )}
                    </div>
                    
                    {!isSetMode && (
                        <div className="form-summary">
                            <h3>Summary</h3>
                            <p><strong>Taxable Amount:</strong> <span>{calculations.taxableAmount.toFixed(2)}</span></p>
                            <p><strong>GST ({calculations.gstRate}%):</strong> <span>{calculations.gstAmount.toFixed(2)}</span></p>
                            <p><strong>Total Amount:</strong> <span>{calculations.totalAmount.toFixed(2)}</span></p>
                        </div>
                    )}
                    
                    <div className="form-actions">
                        <button type="submit" className="primary-button full-width">{isEditMode ? 'Update Entry' : 'Save Purchase Entry'}</button>
                        {isEditMode && <button type="button" className="secondary-button full-width" onClick={onCancelEdit}>Cancel Edit</button>}
                    </div>
                </form>
            </div>
            <div className="card">
                <div className="card-header">
                    <h2>Recent Entries</h2>
                    <div className="card-header-actions">
                        {hasPendingChanges && (
                            <>
                                <button onClick={handleSaveChanges} className="success-button">Save Changes</button>
                                <button onClick={handleDiscardChanges} className="secondary-button">Discard</button>
                            </>
                        )}
                         <button onClick={handleExport} className="secondary-button" disabled={entries.length === 0 || hasPendingChanges}>
                            {selectedEntryIds.size > 0 ? `Export Selected (${selectedEntryIds.size})` : 'Export All'}
                        </button>
                        <button onClick={() => onDeleteSelectedEntries(selectedEntryIds)} className="danger-button" disabled={selectedEntryIds.size === 0 || hasPendingChanges}>
                            Delete Selected
                        </button>
                        <button onClick={onClearAllEntries} className="danger-button" disabled={entries.length === 0 || hasPendingChanges}>Clear All</button>
                    </div>
                </div>
                <div className="table-wrapper">
                  <table>
                      <thead>
                          <tr>
                              <th style={{width: '40px'}}><input type="checkbox" onChange={e => handleSelectAll(e.target.checked)} checked={allSelected} aria-label="Select all entries" /></th>
                              <th style={{width: '120px'}}>Dept.</th>
                              <th style={{width: '250px'}}>Product</th>
                              <th style={{width: '120px'}}>Brand</th>
                              <th style={{width: '90px'}}>Qty</th>
                              <th style={{width: '110px'}}>Landing Rate</th>
                              <th style={{width: '100px'}}>MRP</th>
                              <th style={{width: '60px'}}>GST</th>
                              <th style={{width: '120px'}}>Taxable Amt.</th>
                              <th style={{width: '110px'}}>Selling Price</th>
                              <th style={{width: '120px'}}>Actions</th>
                          </tr>
                      </thead>
                      <tbody>
                          {entries.length > 0 ? entries.map(entry => {
                              const currentData = { ...entry, ...(editedEntries[entry.id] || {}) };
                              const taxableAmount = (currentData.quantity || 0) * (currentData.landingRate || 0);
                              
                              const getCellClass = (field: keyof PurchaseEntry) => {
                                  return editedEntries[entry.id]?.[field] !== undefined ? 'dirty-cell' : '';
                              };

                              return (
                              <tr key={entry.id} className={selectedEntryIds.has(entry.id) ? 'selected-row' : ''}>
                                  <td><input type="checkbox" onChange={e => handleSelectOne(entry.id, e.target.checked)} checked={selectedEntryIds.has(entry.id)} aria-label={`Select entry for ${entry.productName}`} /></td>
                                  <td title={getDepartmentInfo(entry.departmentId, 'name') as string}><div className="truncate">{getDepartmentInfo(entry.departmentId, 'name')}</div></td>
                                  <td className="product-details-cell">
                                      <div className="product-name-main" title={entry.productName}>{entry.productName}</div>
                                      <div className="product-sub-details" title={[entry.color, entry.size, entry.productCode].filter(Boolean).join(', ')}>
                                          {[entry.color, entry.size, entry.productCode].filter(Boolean).join(' · ')}
                                      </div>
                                  </td>
                                  <td title={entry.brandName}><div className="truncate">{entry.brandName}</div></td>
                                  <td className={getCellClass('quantity')}><input type="text" value={currentData.quantity} onChange={e => handleTableInputChange(entry.id, 'quantity', e.target.value)} className="inline-edit-input" /></td>
                                  <td className={getCellClass('landingRate')}><input type="text" value={currentData.landingRate} onChange={e => handleTableInputChange(entry.id, 'landingRate', e.target.value)} className="inline-edit-input" /></td>
                                  <td className={getCellClass('mrp')}><input type="text" value={currentData.mrp} onChange={e => handleTableInputChange(entry.id, 'mrp', e.target.value)} className="inline-edit-input" /></td>
                                  <td>{getDepartmentInfo(entry.departmentId, 'gst')}%</td>
                                  <td>{taxableAmount.toFixed(2)}</td>
                                  <td className={getCellClass('sellingPrice')}><input type="text" value={currentData.sellingPrice} onChange={e => handleTableInputChange(entry.id, 'sellingPrice', e.target.value)} className="inline-edit-input" /></td>
                                  <td className="actions-cell">
                                      <button onClick={() => onViewEntry(entry)} className="icon-button" aria-label={`View details for ${entry.productName}`}>👁️</button>
                                      <button onClick={() => onStartEdit(entry.id)} className="icon-button" aria-label={`Edit ${entry.productName}`}>✏️</button>
                                      <button onClick={() => onDeleteEntry(entry.id)} className="icon-button danger" aria-label={`Delete ${entry.productName}`}>🗑️</button>
                                  </td>
                              </tr>
                          )}) : (
                              <tr><td colSpan={11}>No entries yet. Add one using the form above.</td></tr>
                          )}
                      </tbody>
                  </table>
                </div>
            </div>
        </div>
    );
};

// --- Excel Converter Page Component ---
const APP_FIELDS_FOR_MAPPING: { key: keyof Partial<Omit<PurchaseEntry, 'id' | 'departmentId'>>, label: string, required: boolean }[] = [
    { key: 'productName', label: 'Item Name / Product Name', required: true },
    { key: 'quantity', label: 'Quantity', required: true },
    { key: 'mrp', label: 'MRP (Retail/Listed Price)', required: true },
    { key: 'landingRate', label: 'Rate (Landing Rate)', required: false },
    { key: 'sellingPrice', label: 'Sales Price', required: false },
    { key: 'brandName', label: 'Brand', required: false },
    { key: 'productCode', label: 'Product Code', required: false },
    { key: 'color', label: 'Color', required: false },
    { key: 'size', label: 'Size', required: false },
    { key: 'warranty', label: 'Warranty', required: false },
    { key: 'hsn', label: 'HSN Code', required: false },
    { key: 'demBarcode', label: 'OEM Barcode', required: false },
];

const AUTO_MAP_KEYWORDS: Record<string, string> = {
    'product name': 'productName', 'item name': 'productName', 'name': 'productName',
    'mrp': 'mrp', 'listed mrp': 'mrp', 'retail price': 'mrp', 'price': 'mrp', 'online mrp': 'mrp',
    'quantity': 'quantity', 'qty': 'quantity', 'stock': 'quantity',
    'rate': 'landingRate', 'landing rate': 'landingRate', 'purchase price': 'landingRate', 'discounted rate': 'landingRate',
    'sales price': 'sellingPrice',
    'brand': 'brandName', 'brand name': 'brandName',
    'product code': 'productCode', 'code': 'productCode', 'sku': 'productCode', 'item code': 'productCode', 'product cod': 'productCode',
    'color': 'color', 'colour': 'color',
    'size': 'size',
    'warranty': 'warranty',
    'hsn code': 'hsn', 'hsn': 'hsn',
    'barcode': 'demBarcode', 'oem barcode': 'demBarcode'
};

const ExcelConverterPage = ({ categories, departments, onAddMultipleEntries }: {
    categories: Category[];
    departments: Department[];
    onAddMultipleEntries: (entries: Omit<PurchaseEntry, 'id'>[]) => void;
}) => {
    const [file, setFile] = useState<File | null>(null);
    const [headers, setHeaders] = useState<string[]>([]);
    const [rows, setRows] = useState<any[]>([]);
    const [columnMap, setColumnMap] = useState<Record<string, string>>({}); // { appFieldKey: fileHeaderName }
    const [commonData, setCommonData] = useState({
        departmentId: '', brandName: '', marginPercentage: '50',
        discountPercentage: '10', warranty: '',
    });
    const [step, setStep] = useState(1); // 1: Upload, 2: Map, 3: Preview & Import
    const [previewRows, setPreviewRows] = useState<any[]>([]);
    const [isLandingRateTotal, setIsLandingRateTotal] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const resetState = () => {
        setFile(null);
        setHeaders([]);
        setRows([]);
        setColumnMap({});
        if (fileInputRef.current) fileInputRef.current.value = '';
        setStep(1);
        setPreviewRows([]);
        setIsLandingRateTotal(false);
    };
    
    const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (!selectedFile) return;

        setFile(selectedFile);
        const reader = new FileReader();
        reader.onload = (evt) => {
            try {
                const data = evt.target?.result;
                const workbook = XLSX.read(data, { type: 'binary' });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const json: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                if (json.length < 2) {
                    alert("The selected file is empty or has no data rows.");
                    resetState();
                    return;
                }

                const fileHeaders = json[0].map(String).filter(h => h.trim() !== '');
                const fileRows = json.slice(1).map(row => {
                    const rowData: Record<string, any> = {};
                    fileHeaders.forEach((header, index) => {
                        rowData[header] = row[index];
                    });
                    return rowData;
                });
                
                // Auto-mapping
                const initialMap: Record<string, string> = {};
                const usedFileHeaders = new Set<string>();

                APP_FIELDS_FOR_MAPPING.forEach(appField => {
                    for (const fileHeader of fileHeaders) {
                         if (usedFileHeaders.has(fileHeader)) continue;
                         const lowerFileHeader = fileHeader.toLowerCase().trim();
                         const matchedKeyword = Object.keys(AUTO_MAP_KEYWORDS).find(keyword => 
                            AUTO_MAP_KEYWORDS[keyword] === appField.key && keyword === lowerFileHeader
                         );

                         if (matchedKeyword) {
                            initialMap[appField.key] = fileHeader;
                            usedFileHeaders.add(fileHeader);
                            break;
                         }
                    }
                });

                setHeaders(fileHeaders);
                setRows(fileRows);
                setColumnMap(initialMap);
                setStep(2);

            } catch (error) {
                console.error("Error parsing Excel file:", error);
                alert("There was an error parsing the file. Please ensure it's a valid Excel (.xlsx) or CSV file.");
                resetState();
            }
        };
        reader.readAsBinaryString(selectedFile);
    };

    const handleMapChange = (appFieldKey: string, fileHeaderName: string) => {
        setColumnMap(prev => ({ ...prev, [appFieldKey]: fileHeaderName }));
    };

    const handleCommonDataChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setCommonData(prev => ({ ...prev, [name]: value }));
    };

    const isMappingValid = useMemo(() => {
        return APP_FIELDS_FOR_MAPPING.every(field => !field.required || (columnMap[field.key] && columnMap[field.key] !== 'none'));
    }, [columnMap]);

    useEffect(() => {
        if (step !== 3) return;

        const margin = parseFloat(commonData.marginPercentage) || 0;
        const discount = parseFloat(commonData.discountPercentage) || 0;
        
        const calculatedRows = rows.map((row, index) => {
            const entry: any = {
                departmentId: commonData.departmentId,
                warranty: commonData.warranty,
                brandName: commonData.brandName,
                marginPercentage: margin,
                discountPercentage: discount,
            };
            
            for (const appFieldKey in columnMap) {
                const fileHeader = columnMap[appFieldKey as keyof typeof columnMap];
                if (fileHeader && fileHeader !== 'none') {
                    const value = row[fileHeader] ?? '';
                    if (String(value).trim() !== '') {
                        entry[appFieldKey] = value;
                    }
                }
            }
            
            const dept = departments.find(d => d.id === entry.departmentId);
            if (!entry.hsn && dept) {
                entry.hsn = dept.hsn;
            }

            const numMrp = parseFloat(entry.mrp);
            const numQty = parseInt(entry.quantity, 10);
            const mappedLandingRate = parseFloat(entry.landingRate);
            const mappedSellingPrice = parseFloat(entry.sellingPrice);

            let finalLandingRate = 0;
            let finalSellingPrice = 0;
            
            const isValidRow = String(entry.productName || '').trim() && !isNaN(numQty) && numQty > 0 && !isNaN(numMrp) && numMrp > 0 && entry.departmentId;

            if (isValidRow) {
                if (!isNaN(mappedLandingRate) && mappedLandingRate > 0) {
                    finalLandingRate = isLandingRateTotal ? (mappedLandingRate / numQty) : mappedLandingRate;
                } else {
                    finalLandingRate = numMrp / (1 + (parseFloat(entry.marginPercentage) / 100));
                }

                if (!isNaN(mappedSellingPrice) && mappedSellingPrice > 0) {
                    finalSellingPrice = mappedSellingPrice;
                } else {
                    finalSellingPrice = numMrp * (1 - (parseFloat(entry.discountPercentage) / 100));
                }
            }
            
            return { 
                ...entry, 
                landingRate: finalLandingRate, 
                sellingPrice: finalSellingPrice, 
                isValid: isValidRow, 
                originalIndex: index,
                productName: entry.productName || '',
                quantity: numQty || 0,
                mrp: numMrp || 0,
                productCode: entry.productCode || '',
                color: entry.color || '',
                size: entry.size || '',
                hsn: entry.hsn || (dept?.hsn || ''),
                demBarcode: entry.demBarcode || '',
            };
        }).filter(entry => String(entry.productName || '').trim() || !isNaN(parseFloat(entry.mrp)) || !isNaN(parseInt(entry.quantity, 10)));
        setPreviewRows(calculatedRows);
    }, [rows, columnMap, commonData, step, isLandingRateTotal, departments]);
    
    const handlePreviewRowChange = (index: number, field: string, value: any) => {
        setPreviewRows(prev => {
            const newRows = [...prev];
            const rowToUpdate = { ...newRows[index] };
            
            (rowToUpdate as any)[field] = value;

            if (['landingRate', 'mrp', 'marginPercentage', 'discountPercentage', 'sellingPrice'].includes(field)) {
                const landingRate = parseFloat(rowToUpdate.landingRate) || 0;
                let mrp = parseFloat(rowToUpdate.mrp) || 0;
                const marginPercentage = parseFloat(rowToUpdate.marginPercentage) || 0;
                const discountPercentage = parseFloat(rowToUpdate.discountPercentage) || 0;

                switch (field) {
                    case 'landingRate':
                    case 'marginPercentage':
                        if (landingRate > 0 && marginPercentage >= 0) {
                            const newMrp = landingRate * (1 + marginPercentage / 100);
                            rowToUpdate.mrp = Math.round(newMrp);
                            const newSellingPrice = Math.round(newMrp) * (1 - (parseFloat(rowToUpdate.discountPercentage) || 0) / 100);
                            rowToUpdate.sellingPrice = Math.round(newSellingPrice);
                        }
                        break;
                    case 'mrp':
                        mrp = parseFloat(value) || 0;
                        if (landingRate > 0 && mrp > 0) {
                            const newMargin = ((mrp / landingRate) - 1) * 100;
                            rowToUpdate.marginPercentage = parseFloat(newMargin.toFixed(2));
                        }
                        if (mrp > 0 && discountPercentage >= 0) {
                            const newSellingPrice = mrp * (1 - discountPercentage / 100);
                            rowToUpdate.sellingPrice = Math.round(newSellingPrice);
                        }
                        break;
                    case 'discountPercentage':
                        if (mrp > 0 && discountPercentage >= 0) {
                            const newSellingPrice = mrp * (1 - discountPercentage / 100);
                            rowToUpdate.sellingPrice = Math.round(newSellingPrice);
                        }
                        break;
                    case 'sellingPrice':
                        const sellingPrice = parseFloat(value) || 0;
                        if (mrp > 0 && sellingPrice >= 0) {
                            const newDiscount = (1 - (sellingPrice / mrp)) * 100;
                            rowToUpdate.discountPercentage = parseFloat(Math.max(0, newDiscount).toFixed(2));
                        }
                        break;
                }
            }
            
            if (field === 'departmentId') {
                const dept = departments.find(d => d.id === value);
                if (dept) rowToUpdate.hsn = dept.hsn;
            }
            
            const numQty = parseInt(rowToUpdate.quantity, 10);
            const numMrp = parseFloat(rowToUpdate.mrp);
            rowToUpdate.isValid = String(rowToUpdate.productName || '').trim() && rowToUpdate.departmentId && !isNaN(numQty) && numQty > 0 && !isNaN(numMrp) && numMrp > 0;

            newRows[index] = rowToUpdate;
            return newRows;
        });
    };

    const handleImport = () => {
        const validEntries = previewRows.filter(e => e.isValid);
        if(validEntries.length === 0) {
            alert('No valid entries to import. Please check your data for missing/invalid Product Name, Department, MRP, or Quantity.');
            return;
        }

        const entriesToCreate: Omit<PurchaseEntry, 'id'>[] = validEntries.map(p => {
             const dept = departments.find(d => d.id === p.departmentId);
             
             return {
                departmentId: p.departmentId,
                productName: String(p.productName).trim(),
                hsn: String(p.hsn || dept?.hsn || '').trim(),
                brandName: String(p.brandName).trim(),
                productCode: String(p.productCode || '').trim(),
                color: String(p.color || '').trim(),
                size: String(p.size || '').trim(),
                warranty: String(p.warranty).trim(),
                demBarcode: String(p.demBarcode || '').trim(),
                pattern: '',
                style: '',
                quantity: parseInt(p.quantity, 10) || 0,
                landingRate: parseFloat(p.landingRate) || 0,
                mrp: parseFloat(p.mrp) || 0,
                sellingPrice: Math.round(parseFloat(p.sellingPrice) || 0),
                marginPercentage: parseFloat(p.marginPercentage) || 0,
                discountPercentage: parseFloat(p.discountPercentage) || 0,
            };
        });

        onAddMultipleEntries(entriesToCreate);
        alert(`${entriesToCreate.length} entries successfully imported!`);
        resetState();
    };

    const componentBody = () => {
        switch(step) {
            case 1:
                return (
                     <div className="card">
                        <h2>Step 1: Upload Supplier Excel File</h2>
                        <p>Select an Excel (.xlsx) or CSV file to import. The first row should contain headers like "Product Name", "MRP", etc.</p>
                        <div className="file-upload-area">
                            <input type="file" id="excel-upload" accept=".xlsx, .xls, .csv" onChange={handleFile} ref={fileInputRef} className="sr-only" />
                            <label htmlFor="excel-upload" className="primary-button">
                                {file ? `Selected: ${file.name}` : 'Choose a file'}
                            </label>
                            {file && <button onClick={resetState} className="secondary-button">Clear</button>}
                        </div>
                    </div>
                );
            case 2:
                return (
                    <div className="card">
                        <div className="card-header">
                            <h2>Step 2: Map Columns</h2>
                            <button onClick={resetState} className="secondary-button">Start Over</button>
                        </div>
                        <p>Match the application fields (left) to the columns from your file (right). Required fields are marked with *.</p>
                        <div className="table-wrapper">
                            <table className="mapping-table">
                                <thead>
                                    <tr><th>Application field</th><th>Map from your file's column</th></tr>
                                </thead>
                                <tbody>
                                    {APP_FIELDS_FOR_MAPPING.map(field => (
                                        <tr key={field.key}>
                                            <td>{field.label}{field.required ? ' *' : ''}</td>
                                            <td>
                                                <select value={columnMap[field.key] || 'none'} onChange={e => handleMapChange(field.key, e.target.value)}>
                                                    <option value="none">-- Do not import --</option>
                                                    {headers.map(header => (
                                                        <option key={header} value={header}>
                                                            {header}
                                                        </option>
                                                    ))}
                                                </select>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="form-actions">
                            <button onClick={() => setStep(3)} disabled={!isMappingValid} className="primary-button">
                                {isMappingValid ? 'Next: Add Details & Preview' : 'Please map all required fields'}
                            </button>
                        </div>
                    </div>
                );
            case 3:
                const validRowCount = previewRows.filter(d => d.isValid).length;
                return (
                    <div className="card">
                        <div className="card-header">
                            <h2>Step 3: Add Details & Preview</h2>
                            <button onClick={resetState} className="secondary-button">Start Over</button>
                        </div>
                        <p>Set common details for all rows, or edit each row individually in the table below. Rows highlighted in red are invalid and will not be imported.</p>
                        
                         <div className="form-grid common-data-form">
                            <SearchableDepartmentSelect label="Department *" name="departmentId" value={commonData.departmentId} onChange={handleCommonDataChange} categories={categories} required />
                            <div className="form-group">
                               <label htmlFor="brandName">Default Brand Name (if not mapped)</label>
                               <input id="brandName" name="brandName" type="text" value={commonData.brandName} onChange={handleCommonDataChange} />
                            </div>
                            <div className="form-group">
                               <label htmlFor="marginPercentage">Margin (%) * (for calculations)</label>
                               <input id="marginPercentage" name="marginPercentage" type="number" min="0" step="0.01" value={commonData.marginPercentage} onChange={handleCommonDataChange} required />
                            </div>
                            <div className="form-group">
                               <label htmlFor="discountPercentage">Discount (%) * (for calculations)</label>
                               <input id="discountPercentage" name="discountPercentage" type="number" min="0" max="100" step="0.01" value={commonData.discountPercentage} onChange={handleCommonDataChange} required />
                            </div>
                            <div className="form-group">
                               <label htmlFor="warranty">Default Warranty (if not mapped)</label>
                               <input id="warranty" name="warranty" type="text" value={commonData.warranty} onChange={handleCommonDataChange} />
                            </div>
                            <div className="form-group form-group-span-2">
                                <div className="form-switch-container">
                                    <label htmlFor="landingRateSwitch" className="form-switch-label">Landing Rate from file is Total (for all Qty)</label>
                                    <label className="form-switch">
                                        <input type="checkbox" id="landingRateSwitch" checked={isLandingRateTotal} onChange={e => setIsLandingRateTotal(e.target.checked)} />
                                        <span className="slider round"></span>
                                    </label>
                                    <span className="switch-explainer">ON = Rate is for all quantities (e.g., 5000 for 5 Qty). We'll calculate the per-item rate (1000).</span>
                                </div>
                            </div>
                         </div>
                         
                         <h3 className="preview-header">Import Preview ({validRowCount} / {previewRows.length} valid rows)</h3>
                         <div className="table-wrapper">
                            <table className="excel-preview-table">
                                <thead>
                                    <tr>
                                        <th style={{width: '200px'}}>Product Name</th>
                                        <th style={{width: '60px'}}>Qty</th>
                                        <th style={{width: '90px'}}>MRP</th>
                                        <th style={{width: '180px'}}>Department</th>
                                        <th style={{width: '120px'}}>Brand</th>
                                        <th style={{width: '120px'}}>Code</th>
                                        <th style={{width: '100px'}}>HSN</th>
                                        <th style={{width: '100px'}}>Warranty</th>
                                        <th style={{width: '100px'}}>Landing</th>
                                        <th style={{width: '90px'}}>Margin %</th>
                                        <th style={{width: '90px'}}>Discount %</th>
                                        <th style={{width: '100px'}}>Selling Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {previewRows.length > 0 ? previewRows.map((p, index) => (
                                        <tr key={p.originalIndex} className={!p.isValid ? 'invalid-row' : ''}>
                                            <td><input type="text" className="inline-edit-input" value={p.productName} onChange={e => handlePreviewRowChange(index, 'productName', e.target.value)} /></td>
                                            <td>{String(p.quantity)}</td>
                                            <td><input type="number" className="inline-edit-input" value={p.mrp} onChange={e => handlePreviewRowChange(index, 'mrp', e.target.value)} /></td>
                                            <td className="compact-cell">
                                                <SearchableDepartmentSelect name={`department-${p.originalIndex}`} value={p.departmentId} onChange={(e) => handlePreviewRowChange(index, 'departmentId', e.target.value)} categories={categories} required label="" />
                                            </td>
                                            <td><input type="text" className="inline-edit-input" value={p.brandName} onChange={e => handlePreviewRowChange(index, 'brandName', e.target.value)} /></td>
                                            <td><input type="text" className="inline-edit-input" value={p.productCode} onChange={e => handlePreviewRowChange(index, 'productCode', e.target.value)} /></td>
                                            <td><input type="text" className="inline-edit-input" value={p.hsn} onChange={e => handlePreviewRowChange(index, 'hsn', e.target.value)} /></td>
                                            <td><input type="text" className="inline-edit-input" value={p.warranty} onChange={e => handlePreviewRowChange(index, 'warranty', e.target.value)} /></td>
                                            <td><input type="number" className="inline-edit-input" value={p.landingRate} onChange={e => handlePreviewRowChange(index, 'landingRate', e.target.value)} /></td>
                                            <td><input type="number" className="inline-edit-input" value={p.marginPercentage} onChange={e => handlePreviewRowChange(index, 'marginPercentage', e.target.value)} /></td>
                                            <td><input type="number" className="inline-edit-input" value={p.discountPercentage} onChange={e => handlePreviewRowChange(index, 'discountPercentage', e.target.value)} /></td>
                                            <td><input type="number" className="inline-edit-input" value={p.sellingPrice} onChange={e => handlePreviewRowChange(index, 'sellingPrice', e.target.value)} /></td>
                                        </tr>
                                    )) : (
                                        <tr><td colSpan={12}>No data to display.</td></tr>
                                    )}
                                </tbody>
                            </table>
                         </div>
                         <div className="form-actions">
                            <button onClick={handleImport} className="primary-button" disabled={validRowCount === 0}>
                                Import {validRowCount} Valid Entries
                            </button>
                         </div>
                     </div>
                );
            default:
                return null;
        }
    }

    return (
        <div className="page-container">
            <div className="page-header">
                <h2>Excel Purchase Converter</h2>
                <p>Import purchase entries directly from a supplier's Excel or CSV file in three easy steps.</p>
            </div>
            {componentBody()}
        </div>
    );
};

// --- View Entry Modal Component ---
const ViewEntryModal = ({ entry, departments, onClose }: { entry: PurchaseEntry, departments: Department[], onClose: () => void }) => {
    useEffect(() => {
        const handleEscape = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
        document.addEventListener('keydown', handleEscape);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleEscape);
            document.body.style.overflow = 'auto';
        };
    }, [onClose]);

    const getDepartmentName = (id: string) => departments.find(d => d.id === id)?.name || 'N/A';
    const dept = departments.find(d => d.id === entry.departmentId);
    const gstRate = dept ? dept.gst : 0;
    const taxableAmount = entry.quantity * entry.landingRate;
    const gstAmount = taxableAmount * (gstRate / 100);
    const totalAmount = taxableAmount + gstAmount;

    const DetailItem = ({ label, value }: { label: string; value: string | number; }) => (
        <div className="detail-item">
            <strong>{label}</strong>
            <span>{value || '-'}</span>
        </div>
    );

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={e => e.stopPropagation()}>
                <div className="modal-header">
                    <h2>Entry Details</h2>
                    <button onClick={onClose} className="close-button" aria-label="Close modal">&times;</button>
                </div>
                <div className="modal-body">
                    <h3>{entry.productName}</h3>
                    <div className="detail-grid">
                        <DetailItem label="Department" value={getDepartmentName(entry.departmentId)} />
                        <DetailItem label="Brand" value={entry.brandName} />
                        <DetailItem label="HSN" value={entry.hsn} />
                        <DetailItem label="Product Code" value={entry.productCode} />
                        <DetailItem label="DEM Barcode" value={entry.demBarcode} />
                        <DetailItem label="Color" value={entry.color} />
                        <DetailItem label="Size (Type)" value={entry.size} />
                        <DetailItem label="Warranty" value={entry.warranty} />
                        <DetailItem label="Margin" value={`${entry.marginPercentage.toFixed(2)}%`} />
                        <DetailItem label="Discount" value={`${entry.discountPercentage.toFixed(2)}%`} />
                    </div>
                    <div className="summary-section">
                        <div className="detail-grid">
                            <DetailItem label="Quantity" value={entry.quantity} />
                            <DetailItem label="Landing Rate" value={`₹${entry.landingRate.toFixed(2)}`} />
                            <DetailItem label="MRP" value={`₹${entry.mrp.toFixed(2)}`} />
                            <DetailItem label="Selling Price" value={`₹${entry.sellingPrice.toFixed(2)}`} />
                            <DetailItem label="Taxable Amount" value={`₹${taxableAmount.toFixed(2)}`} />
                            <DetailItem label={`GST (${gstRate}%)`} value={`₹${gstAmount.toFixed(2)}`} />
                            <DetailItem label="Total Amount" value={`₹${totalAmount.toFixed(2)}`} />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- Styles ---
const STYLES = `
    :root {
        --primary-color: #4f46e5;
        --primary-color-hover: #4338ca;
        --primary-color-light: #e0e7ff;
        --secondary-color: #6b7280;
        --secondary-color-hover: #4b5563;
        --bg-color: #f9fafb;
        --card-bg: #ffffff;
        --text-color: #111827;
        --text-color-light: #6b7280;
        --border-color: #e5e7eb;
        --danger-color: #ef4444;
        --danger-color-hover: #dc2626;
        --danger-color-light: #fee2e2;
        --success-color: #22c55e;
        --success-color-hover: #16a34a;
        --success-color-light: #dcfce7;
        --focus-ring-color: rgba(79, 70, 229, 0.25);
        --sidebar-bg: #1f2937;
        --sidebar-text: #f9fafb;
        --sidebar-active-bg: var(--primary-color);
        --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
        --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        --border-radius: 0.5rem;
        --font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }
    *, *::before, *::after { box-sizing: border-box; }
    body {
        margin: 0;
        font-family: var(--font-family);
        background-color: var(--bg-color);
        color: var(--text-color);
        line-height: 1.6;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    .app-layout { display: flex; min-height: 100vh; }
    .sidebar {
        width: 240px;
        background-color: var(--sidebar-bg);
        color: var(--sidebar-text);
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
        border-right: 1px solid #374151;
    }
    .sidebar-header { padding: 1.5rem; }
    .sidebar-header h1 { margin: 0; font-size: 1.75rem; color: var(--sidebar-text); font-weight: 700; }
    .sidebar-nav { display: flex; flex-direction: column; padding: 1rem 0; }
    .sidebar-nav button {
        background: none; border: none; padding: 0.8rem 1.5rem; font-size: 1rem;
        cursor: pointer; color: #d1d5db; font-weight: 500;
        text-align: left;
        border-left: 4px solid transparent;
        transition: background-color 0.2s, border-color 0.2s, color 0.2s;
    }
    .sidebar-nav button:hover { background-color: #374151; color: var(--sidebar-text); }
    .sidebar-nav button.active {
        background-color: var(--sidebar-active-bg);
        border-left-color: #a5b4fc;
        color: var(--sidebar-text);
        font-weight: 600;
    }
    .main-content { flex-grow: 1; padding: 2rem; overflow-y: auto; }
    
    .page-container { display: flex; flex-direction: column; gap: 2rem; max-width: 1400px; margin: 0 auto; }
    .page-header { margin-bottom: 1rem; }
    .page-header h2 { font-size: 1.875rem; font-weight: 700; margin: 0 0 0.5rem 0;}
    .page-header p { font-size: 1rem; color: var(--text-color-light); margin: 0; max-width: 80ch; }

    .card { background-color: var(--card-bg); padding: 2rem; border-radius: var(--border-radius); box-shadow: var(--shadow); border: 1px solid var(--border-color); }
    .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;}
    .card h2 {
        margin: 0; font-size: 1.25rem; font-weight: 600;
    }
    .card h3 { margin-top: 0; margin-bottom: 1rem; font-size: 1.1rem; }
    .card-header h2, .card-header h3 { border-bottom: none; padding-bottom: 0; margin-bottom: 0; }
    .card > p { margin-top: -1rem; margin-bottom: 1.5rem; color: var(--secondary-color); }
    .card-header-actions { display: flex; gap: 0.75rem; }

    .form-group { display: flex; flex-direction: column; gap: 0.5rem; }
    .form-group > label, fieldset > legend { font-weight: 500; color: #374151; font-size: 0.875rem;}
    input, select {
        width: 100%; padding: 0.625rem 0.875rem; border: 1px solid var(--border-color);
        border-radius: 0.375rem; font-size: 1rem; transition: border-color 0.2s, box-shadow 0.2s;
        background-color: #fff;
    }
    input:focus, select:focus {
        outline: none; border-color: var(--primary-color);
        box-shadow: 0 0 0 3px var(--focus-ring-color);
    }
    input:disabled {
        background-color: #f3f4f6;
        cursor: not-allowed;
        color: var(--text-color-light);
    }
    input[type="search"] { -webkit-appearance: none; }
    
    .primary-button, .secondary-button, .danger-button, .success-button {
        border: none; padding: 0.625rem 1.25rem; border-radius: 0.375rem; font-size: 0.9rem; font-weight: 600; cursor: pointer; transition: background-color 0.2s, opacity 0.2s;
        display: inline-flex; align-items: center; justify-content: center;
    }
    .primary-button { background-color: var(--primary-color); color: white; }
    .primary-button:hover { background-color: var(--primary-color-hover); }
    .primary-button:disabled { opacity: 0.6; cursor: not-allowed; }
    
    .secondary-button { background-color: #fff; color: #374151; border: 1px solid var(--border-color); }
    .secondary-button:hover { background-color: #f9fafb; }
    .secondary-button:disabled { opacity: 0.6; cursor: not-allowed; }
    
    .danger-button { background-color: var(--danger-color); color: white; }
    .danger-button:hover { background-color: var(--danger-color-hover); }
    .danger-button:disabled { opacity: 0.6; cursor: not-allowed; }
    
    .success-button { background-color: var(--success-color); color: white; }
    .success-button:hover { background-color: var(--success-color-hover); }

    .primary-button.full-width, .secondary-button.full-width { width: 100%; }
    .form-actions { display: flex; gap: 1rem; margin-top: 1.5rem; }

    .sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border-width: 0; }
    
    .category-list { display: flex; flex-direction: column; gap: 1.5rem; }
    .department-list { list-style: none; padding: 0; margin: 0; }
    .department-list li { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; border-bottom: 1px solid var(--border-color); flex-wrap: wrap; gap: 1rem; }
    .department-list li:last-child { border-bottom: none; }
    .settings-list { margin-top: 1.5rem; }
    .department-name { font-weight: 500; flex-basis: 200px; flex-shrink: 0; }
    
    .category-card { padding: 1.5rem; }
    .category-header { 
        display: flex; justify-content: space-between; align-items: center; 
        cursor: pointer; 
    }
    .category-header h3 { 
        margin: 0; font-size: 1.1rem; color: var(--primary-color); 
        display: flex; align-items: center; gap: 0.75rem; font-weight: 600;
    }
    .toggle-icon { transition: transform 0.2s ease-in-out; display: inline-block; font-size: 0.8em; }
    .toggle-icon.expanded { transform: rotate(90deg); }
    
    .collapsible-content { animation: slideDown 0.3s ease-out; overflow: hidden; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border-color); }
    @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); max-height: 0; } to { opacity: 1; transform: translateY(0); max-height: 1000px; } }

    .add-category-form, .add-department-form { display: flex; gap: 1rem; margin-bottom: 1rem; }
    .add-category-form input, .add-department-form input { flex-grow: 1; }
    .add-department-form { margin-bottom: 1.5rem; }

    .settings-controls { display: flex; align-items: center; gap: 1.5rem; flex-grow: 1; justify-content: flex-end; }
    .hsn-group { max-width: 150px; }
    .hsn-group input { padding: 0.5rem; }

    .radio-group-inline { display: flex; gap: 1rem; border: none; padding: 0; margin: 0; }
    .radio-group-inline label { display: flex; align-items: center; gap: 0.5rem; font-weight: normal; cursor: pointer; padding: 0.25rem 0.5rem; border-radius: 4px; transition: background-color 0.2s; }
    .radio-group-inline input { width: auto; }
    .radio-group-inline label:has(input:checked) { color: var(--primary-color); font-weight: 500; }
    .empty-state { color: var(--text-color-light); font-style: italic; text-align: center; padding: 1rem; }

    .entry-form .form-section { padding-top: 2rem; }
    .entry-form .form-section:first-child { padding-top: 0; }
    .entry-form .form-section .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;}
    .entry-form .form-section h3 { margin: 0; font-size: 1rem; color: var(--secondary-color); font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; padding-bottom: 0.75rem; border-bottom: 1px solid var(--border-color); }
    .form-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1.5rem; }
    .form-summary { margin-top: 2rem; padding: 1.5rem; border: 1px solid var(--border-color); border-radius: var(--border-radius); background-color: var(--bg-color); }
    .form-summary h3 { margin-top: 0; }
    .form-summary p { margin: 0.5rem 0; display: flex; justify-content: space-between;}
    .form-summary p span { font-weight: 600; }
    
    .table-wrapper { overflow-x: auto; border: 1px solid var(--border-color); border-radius: var(--border-radius); }
    table { width: 100%; border-collapse: collapse; font-size: 0.9rem; table-layout: fixed; }
    th, td { padding: 0.8rem; text-align: left; border-bottom: 1px solid var(--border-color); vertical-align: middle; }
    thead tr:first-child th { border-top: none; }
    tbody tr:last-child td { border-bottom: none; }
    th { font-weight: 600; background-color: var(--bg-color); color: var(--text-color-light); text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.05em; }
    tbody tr:hover { background-color: #f9fafb; }
    tbody tr.selected-row { background-color: var(--primary-color-light) !important; }
    tbody tr.invalid-row { background-color: var(--danger-color-light); color: #991b1b; }
    th:first-child, td:first-child { text-align: center; }
    td:not(.actions-cell):not(:first-child) { padding: 0; }
    td > div { padding: 0.4rem 0.8rem; }
    .product-details-cell > div { padding: 0.2rem 0.8rem; }
    .product-details-cell > .product-name-main { padding-top: 0.4rem; }
    .product-details-cell > .product-sub-details { padding-bottom: 0.4rem; }
    .compact-cell { padding: 2px !important; }

    .truncate { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

    .product-details-cell { line-height: 1.3; }
    .product-details-cell .product-name-main { font-weight: 500; color: var(--text-color); }
    .product-details-cell .product-sub-details { font-size: 0.8rem; color: var(--text-color-light); }

    .actions-cell { text-align: right; white-space: nowrap; padding: 0.4rem 0.8rem; }
    .icon-button { background: none; border: none; cursor: pointer; padding: 0.5rem; font-size: 1rem; border-radius: 50%; line-height: 1; transition: background-color 0.2s, color 0.2s; vertical-align: middle; color: var(--text-color-light); }
    .icon-button:hover { background-color: var(--border-color); color: var(--text-color); }
    .icon-button.danger:hover { background-color: var(--danger-color-light); color: var(--danger-color); }
    .icon-button.success:hover { background-color: var(--success-color-light); color: var(--success-color); }

    .inline-edit-input { width: 100%; height: 100%; border: none; background: transparent; font-family: inherit; font-size: 0.9rem; text-align: left; padding: 0.6rem 0.8rem; border-radius: 0; }
    .inline-edit-input:focus { outline: 2px solid var(--primary-color); outline-offset: -2px; background-color: white; }
    td.dirty-cell { background-color: #fefce8; }

    .autocomplete-wrapper { position: relative; }
    .suggestions-list {
        position: absolute; top: 100%; left: 0; right: 0;
        background-color: var(--card-bg);
        border: 1px solid var(--border-color);
        border-radius: 0 0 0.375rem 0.375rem;
        list-style: none; padding: 0.25rem 0; margin: 2px 0 0 0;
        max-height: 200px; overflow-y: auto;
        z-index: 10;
        box-shadow: var(--shadow-lg);
    }
    .suggestions-list li { padding: 0.625rem 0.875rem; cursor: pointer; }
    .suggestions-list li:hover { background-color: var(--bg-color); }
    .suggestions-list li strong { background-color: transparent; color: var(--primary-color); font-weight: 600; }
    .suggestions-list .suggestion-category { padding: 0.5rem 0.875rem; font-weight: 600; color: var(--text-color-light); background-color: var(--bg-color); font-size: 0.8rem; position: sticky; top: 0; }
    .suggestions-list .suggestion-item-empty { padding: 0.75rem; color: var(--text-color-light); cursor: default; }
    .suggestions-list .suggestion-item-empty:hover { background-color: transparent; }
    
    .modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0,0,0,0.6); display: flex; justify-content: center; align-items: center; z-index: 1000; animation: fadeIn 0.3s ease; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .modal-content { background: white; padding: 2rem; border-radius: var(--border-radius); max-width: 700px; width: 90%; max-height: 90vh; overflow-y: auto; box-shadow: var(--shadow-lg); animation: slideIn 0.3s ease-out; }
    @keyframes slideIn { from { transform: translateY(-30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .modal-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem; margin-bottom: 1.5rem; }
    .modal-header h2 { margin: 0; font-size: 1.5rem; }
    .close-button { background: none; border: none; font-size: 2rem; cursor: pointer; color: var(--secondary-color); line-height: 1; padding: 0; }
    .modal-body h3 { margin-top: 0; font-size: 1.25rem; }
    .detail-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem 2rem; }
    .detail-item strong { display: block; font-weight: 500; color: var(--text-color-light); margin-bottom: 0.25rem; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; }
    .detail-item span { font-size: 1rem; }
    .summary-section { margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--border-color); }

    /* Product Attributes Page Specific Styles */
    .attribute-manager-layout { display: grid; grid-template-columns: 1fr 2fr; gap: 2rem; align-items: start; }
    .attribute-controls h3 { margin-bottom: 1.5rem; }
    .add-attribute-form { margin-top: 1.5rem; }
    .input-with-button { display: flex; gap: 0.5rem; }
    .input-with-button input { flex-grow: 1; }
    .input-with-button button { flex-shrink: 0; padding: 0 1.2rem; }
    
    .attribute-list-container .card-header { padding: 0; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem; }
    .search-bar { max-width: 250px; }
    .search-bar input { padding: 0.5rem; }
    .attribute-list { list-style: none; padding: 0; margin: 0; max-height: 500px; overflow-y: auto; }
    .attribute-list li { display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; border-bottom: 1px solid var(--border-color); }
    .attribute-list li:last-child { border-bottom: none; }
    .attribute-list li.empty-state { justify-content: center; border-bottom: none; }
    .attribute-list li > span { padding: 0.5rem; }
    .item-actions { display: flex; align-items: center; }
    .edit-attribute-form { display: flex; width: 100%; gap: 0.5rem; align-items: center; }
    .edit-attribute-form input { flex-grow: 1; }
    
    /* Multi Autocomplete Styles */
    .multi-autocomplete-container { display: flex; flex-wrap: wrap; gap: 0.5rem; padding: 0.375rem; border: 1px solid var(--border-color); border-radius: 0.375rem; cursor: text; transition: border-color 0.2s, box-shadow 0.2s; min-height: calc(1.6em + 1.25rem + 2px); }
    .multi-autocomplete-container:focus-within { outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 3px var(--focus-ring-color); }
    .tag { background-color: var(--primary-color); color: white; padding: 0.25rem 0.75rem; border-radius: 1rem; display: flex; align-items: center; gap: 0.5rem; font-size: 0.9rem; font-weight: 500; line-height: 1.5; }
    .tag-remove { background: none; border: none; color: white; cursor: pointer; font-weight: bold; padding: 0; line-height: 1; opacity: 0.7; }
    .tag-remove:hover { opacity: 1; }
    .multi-autocomplete-input { border: none; outline: none; padding: 0.375rem; flex-grow: 1; font-size: 1rem; min-width: 120px; background: transparent; }
    
    /* Set Mode Styles */
    .form-switch-container { display: flex; align-items: center; gap: 0.75rem; }
    .form-switch-label { font-weight: 500; font-size: 0.9rem; color: #495057; }
    .form-switch { position: relative; display: inline-block; width: 50px; height: 28px; flex-shrink: 0; }
    .form-switch input { opacity: 0; width: 0; height: 0; }
    .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; }
    .slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 4px; bottom: 4px; background-color: white; transition: .4s; }
    input:checked + .slider { background-color: var(--primary-color); }
    input:focus + .slider { box-shadow: 0 0 1px var(--primary-color); }
    input:checked + .slider:before { transform: translateX(22px); }
    .slider.round { border-radius: 28px; }
    .slider.round:before { border-radius: 50%; }
    .switch-explainer { font-size: 0.8rem; color: var(--secondary-color); }

    .set-items-container { border: 1px solid var(--border-color); border-radius: var(--border-radius); padding: 1.5rem; margin-top: 1.5rem; display: flex; flex-direction: column; gap: 1.5rem; background-color: #f9fafb;}
    .set-items-container h4 { margin: 0 0 0.5rem 0; font-size: 1rem; color: var(--text-color); }
    .set-item-row { display: grid; grid-template-columns: repeat(6, 1fr) auto; gap: 1rem; align-items: flex-end; }
    .set-item-row .form-group { margin-bottom: 0; }
    .remove-set-item { font-size: 1.5rem; font-weight: bold; line-height: 1; height: 44px; }
    .set-items-actions { margin-top: 0.5rem; }
    .set-summary { margin-top: 1rem; padding-top: 1rem; border-top: 1px dashed var(--border-color); font-weight: 500; font-size: 0.9rem; color: var(--secondary-color); }
    
    /* Color/Code Pair Input Styles */
    .form-group-span-2 { grid-column: span 2; }
    .pair-input-container { display: flex; flex-direction: column; gap: 1rem; padding: 1rem; border: 1px solid var(--border-color); border-radius: var(--border-radius); background-color: var(--bg-color); }
    .pair-input-row { display: grid; grid-template-columns: 1fr 1fr auto; gap: 1rem; align-items: flex-end; }
    .pair-input-row .form-group { margin: 0; }
    .pair-input-row .form-group > label { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border-width: 0; }
    .remove-pair-button { height: 44px; margin-bottom: 0; font-size: 1.5rem; font-weight: bold; line-height: 1; }
    .pair-input-actions { margin-top: 0.5rem; }

    /* Excel Converter Styles */
    .file-upload-area { display: flex; flex-direction: column; gap: 1rem; align-items: center; justify-content: center; padding: 2rem; border: 2px dashed var(--border-color); border-radius: var(--border-radius); }
    .mapping-table td, .mapping-table th { padding: 0.75rem; }
    .mapping-table select { font-size: 0.9rem; padding: 0.5rem; }
    .common-data-form { margin-bottom: 2rem; }
    .preview-header { margin-top: 2rem; border-top: 1px solid var(--border-color); padding-top: 1.5rem; }
    
    .excel-preview-table { table-layout: auto; }
    .excel-preview-table td { vertical-align: top; }
    .excel-preview-table .compact-cell .form-group { margin-bottom: 0; }
    .excel-preview-table .compact-cell .form-group label { display: none; }
    .excel-preview-table .compact-cell .form-group input { padding: 0.6rem 0.8rem; font-size: 0.9rem; height: auto; border-radius: 4px; border: none; background: transparent; }
    .excel-preview-table .compact-cell .autocomplete-wrapper .suggestions-list { font-size: 0.9rem; width: 300px; }


    @media (max-width: 1200px) {
      .set-item-row { grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); }
      .remove-set-item { grid-column: 1 / -1; justify-self: end; }
    }
    @media (max-width: 992px) {
      .attribute-manager-layout { grid-template-columns: 1fr; }
    }
    @media (max-width: 768px) {
        .app-layout { flex-direction: column; }
        .sidebar { width: 100%; height: auto; flex-direction: row; justify-content: space-between; align-items: center; }
        .sidebar-nav { flex-direction: row; }
        .sidebar-nav button { border-left: none; border-bottom: 4px solid transparent; }
        .sidebar-nav button.active { border-bottom-color: #a5b4fc; }
        .main-content { padding: 1rem; }
        .settings-controls { flex-direction: column; align-items: flex-start; gap: 0.5rem; }
        .form-grid { grid-template-columns: 1fr; }
        .form-group-span-2 { grid-column: span 1; }
        .pair-input-row { grid-template-columns: 1fr; }
        .remove-pair-button { grid-row: 3; justify-self: end; }
    }
`;

// --- Render App ---
const container = document.getElementById('root');
if (container) {
    const root = createRoot(container);
    root.render(<App />);
}